#!/usr/bin/env python
# coding=utf-8
from pwn import *
f = open("./pp").read()
f+='\x90'*(4-(len(f)%4))
arr = []
for i in range(0,len(f),4):
    arr.append(u32(f[i:i+4]))

print(arr)
