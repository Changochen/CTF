#include "src/builtins/builtins-utils-gen.h"
#include "src/builtins/builtins.h"
#include "src/code-factory.h"
#include "src/elements-kind.h"
#include "src/heap/factory-inl.h"
#include "src/objects.h"
#include "src/objects/arguments.h"
#include "src/objects/bigint.h"
#include "src/objects/free-space.h"
#include "src/objects/js-generator.h"
#include "src/objects/js-promise.h"
#include "src/objects/js-regexp-string-iterator.h"
#include "src/objects/module.h"
#include "src/objects/stack-frame-info.h"
#include "src/builtins/builtins-array-gen.h"
#include "src/builtins/builtins-collections-gen.h"
#include "src/builtins/builtins-data-view-gen.h"
#include "src/builtins/builtins-iterator-gen.h"
#include "src/builtins/builtins-proxy-gen.h"
#include "src/builtins/builtins-proxy-gen.h"
#include "src/builtins/builtins-regexp-gen.h"
#include "src/builtins/builtins-regexp-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-constructor-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "torque-generated/builtins-base-from-dsl-gen.h"
#include "torque-generated/builtins-growable-fixed-array-from-dsl-gen.h"
#include "torque-generated/builtins-arguments-from-dsl-gen.h"
#include "torque-generated/builtins-array-from-dsl-gen.h"
#include "torque-generated/builtins-array-copywithin-from-dsl-gen.h"
#include "torque-generated/builtins-array-filter-from-dsl-gen.h"
#include "torque-generated/builtins-array-find-from-dsl-gen.h"
#include "torque-generated/builtins-array-findindex-from-dsl-gen.h"
#include "torque-generated/builtins-array-foreach-from-dsl-gen.h"
#include "torque-generated/builtins-array-join-from-dsl-gen.h"
#include "torque-generated/builtins-array-lastindexof-from-dsl-gen.h"
#include "torque-generated/builtins-array-of-from-dsl-gen.h"
#include "torque-generated/builtins-array-map-from-dsl-gen.h"
#include "torque-generated/builtins-array-reverse-from-dsl-gen.h"
#include "torque-generated/builtins-array-shift-from-dsl-gen.h"
#include "torque-generated/builtins-array-slice-from-dsl-gen.h"
#include "torque-generated/builtins-array-splice-from-dsl-gen.h"
#include "torque-generated/builtins-array-unshift-from-dsl-gen.h"
#include "torque-generated/builtins-collections-from-dsl-gen.h"
#include "torque-generated/builtins-data-view-from-dsl-gen.h"
#include "torque-generated/builtins-extras-utils-from-dsl-gen.h"
#include "torque-generated/builtins-iterator-from-dsl-gen.h"
#include "torque-generated/builtins-object-from-dsl-gen.h"
#include "torque-generated/builtins-proxy-from-dsl-gen.h"
#include "torque-generated/builtins-regexp-from-dsl-gen.h"
#include "torque-generated/builtins-regexp-replace-from-dsl-gen.h"
#include "torque-generated/builtins-string-from-dsl-gen.h"
#include "torque-generated/builtins-string-html-from-dsl-gen.h"
#include "torque-generated/builtins-string-repeat-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-createtypedarray-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-every-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-filter-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-find-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-findindex-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-foreach-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-reduce-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-reduceright-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-slice-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-some-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-subarray-from-dsl-gen.h"
#include "torque-generated/builtins-test-from-dsl-gen.h"

namespace v8 {
namespace internal {

compiler::TNode<Object> ArrayShiftBuiltinsFromDSLAssembler::TryFastArrayShift(compiler::TNode<Context> p_context, compiler::TNode<Object> p_receiver, BaseBuiltinsFromDSLAssembler::Arguments p_arguments, compiler::CodeAssemblerLabel* label_Slow) {
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT> block0(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object> block4(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object, JSArray> block3(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Context, Map> block7(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Context, Map, Int32T> block6(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Context> block5(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT> block8(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT> block9(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi> block12(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi> block13(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi> block14(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi> block15(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Smi, Context, Smi> block20(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Smi, Context, Smi, JSArray, Smi> block24(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Smi, Context, Smi, JSArray, Smi, Object> block23(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Smi, Context, Smi> block21(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Smi, Context, Smi, JSArray, Smi> block26(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Smi, Context, Smi, JSArray, Smi, Object> block25(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Smi, Context, Smi, Object> block19(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi> block18(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Context, Smi, Object> block16(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, Smi, Smi> block27(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT> block29(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArrayBase> block35(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArrayBase, FixedDoubleArray> block34(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT> block33(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedDoubleArray> block32(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT> block30(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArrayBase> block39(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArrayBase, FixedArray> block38(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT> block37(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArray> block36(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArray> block40(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArray> block41(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT, FixedArray> block42(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT> block31(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT, Smi, Object, IntPtrT, IntPtrT, IntPtrT, IntPtrT> block28(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSArray, JSArray, JSArray, Map, BoolT, BoolT, BoolT> block11(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object> block2(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<> block1(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object> block43(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
    ca_.Goto(&block0, p_context, p_receiver, p_arguments.frame, p_arguments.base, p_arguments.length);

  if (block0.is_used()) {
    compiler::TNode<Context> tmp0;
    compiler::TNode<Object> tmp1;
    compiler::TNode<RawPtrT> tmp2;
    compiler::TNode<RawPtrT> tmp3;
    compiler::TNode<IntPtrT> tmp4;
    ca_.Bind(&block0, &tmp0, &tmp1, &tmp2, &tmp3, &tmp4);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 11);
    compiler::TNode<JSArray> tmp5;
    USE(tmp5);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp5 = BaseBuiltinsFromDSLAssembler(state_).Cast13ATFastJSArray(compiler::TNode<Context>{tmp0}, compiler::TNode<Object>{tmp1}, &label0);
    ca_.Goto(&block3, tmp0, tmp1, tmp2, tmp3, tmp4, tmp1, tmp5);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block4, tmp0, tmp1, tmp2, tmp3, tmp4, tmp1);
    }
  }

  if (block4.is_used()) {
    compiler::TNode<Context> tmp6;
    compiler::TNode<Object> tmp7;
    compiler::TNode<RawPtrT> tmp8;
    compiler::TNode<RawPtrT> tmp9;
    compiler::TNode<IntPtrT> tmp10;
    compiler::TNode<Object> tmp11;
    ca_.Bind(&block4, &tmp6, &tmp7, &tmp8, &tmp9, &tmp10, &tmp11);
    ca_.Goto(&block1);
  }

  if (block3.is_used()) {
    compiler::TNode<Context> tmp12;
    compiler::TNode<Object> tmp13;
    compiler::TNode<RawPtrT> tmp14;
    compiler::TNode<RawPtrT> tmp15;
    compiler::TNode<IntPtrT> tmp16;
    compiler::TNode<Object> tmp17;
    compiler::TNode<JSArray> tmp18;
    ca_.Bind(&block3, &tmp12, &tmp13, &tmp14, &tmp15, &tmp16, &tmp17, &tmp18);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 12);
    compiler::TNode<JSArray> tmp19;
    USE(tmp19);
    compiler::TNode<JSArray> tmp20;
    USE(tmp20);
    compiler::TNode<Map> tmp21;
    USE(tmp21);
    compiler::TNode<BoolT> tmp22;
    USE(tmp22);
    compiler::TNode<BoolT> tmp23;
    USE(tmp23);
    compiler::TNode<BoolT> tmp24;
    USE(tmp24);
    std::tie(tmp19, tmp20, tmp21, tmp22, tmp23, tmp24) = BaseBuiltinsFromDSLAssembler(state_).NewFastJSArrayWitness(compiler::TNode<JSArray>{tmp18}).Flatten();
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 14);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2023);
    compiler::TNode<Int32T> tmp25;
    USE(tmp25);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp25 = CodeStubAssembler(state_).EnsureArrayPushable(compiler::TNode<Map>{tmp21}, &label0);
    ca_.Goto(&block6, tmp12, tmp13, tmp14, tmp15, tmp16, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp12, tmp21, tmp25);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block7, tmp12, tmp13, tmp14, tmp15, tmp16, tmp18, tmp19, tmp20, tmp21, tmp22, tmp23, tmp24, tmp12, tmp21);
    }
  }

  if (block7.is_used()) {
    compiler::TNode<Context> tmp26;
    compiler::TNode<Object> tmp27;
    compiler::TNode<RawPtrT> tmp28;
    compiler::TNode<RawPtrT> tmp29;
    compiler::TNode<IntPtrT> tmp30;
    compiler::TNode<JSArray> tmp31;
    compiler::TNode<JSArray> tmp32;
    compiler::TNode<JSArray> tmp33;
    compiler::TNode<Map> tmp34;
    compiler::TNode<BoolT> tmp35;
    compiler::TNode<BoolT> tmp36;
    compiler::TNode<BoolT> tmp37;
    compiler::TNode<Context> tmp38;
    compiler::TNode<Map> tmp39;
    ca_.Bind(&block7, &tmp26, &tmp27, &tmp28, &tmp29, &tmp30, &tmp31, &tmp32, &tmp33, &tmp34, &tmp35, &tmp36, &tmp37, &tmp38, &tmp39);
    ca_.Goto(&block1);
  }

  if (block6.is_used()) {
    compiler::TNode<Context> tmp40;
    compiler::TNode<Object> tmp41;
    compiler::TNode<RawPtrT> tmp42;
    compiler::TNode<RawPtrT> tmp43;
    compiler::TNode<IntPtrT> tmp44;
    compiler::TNode<JSArray> tmp45;
    compiler::TNode<JSArray> tmp46;
    compiler::TNode<JSArray> tmp47;
    compiler::TNode<Map> tmp48;
    compiler::TNode<BoolT> tmp49;
    compiler::TNode<BoolT> tmp50;
    compiler::TNode<BoolT> tmp51;
    compiler::TNode<Context> tmp52;
    compiler::TNode<Map> tmp53;
    compiler::TNode<Int32T> tmp54;
    ca_.Bind(&block6, &tmp40, &tmp41, &tmp42, &tmp43, &tmp44, &tmp45, &tmp46, &tmp47, &tmp48, &tmp49, &tmp50, &tmp51, &tmp52, &tmp53, &tmp54);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2024);
    ArrayBuiltinsFromDSLAssembler(state_).EnsureWriteableFastElements(compiler::TNode<Context>{tmp52}, compiler::TNode<JSArray>{tmp47});
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2025);
    compiler::TNode<BoolT> tmp55;
    USE(tmp55);
    tmp55 = ca_.UncheckedCast<BoolT>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr6ATbool16ATconstexpr_bool(true));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 14);
    ca_.Goto(&block5, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp49, tmp50, tmp55, tmp52);
  }

  if (block5.is_used()) {
    compiler::TNode<Context> tmp56;
    compiler::TNode<Object> tmp57;
    compiler::TNode<RawPtrT> tmp58;
    compiler::TNode<RawPtrT> tmp59;
    compiler::TNode<IntPtrT> tmp60;
    compiler::TNode<JSArray> tmp61;
    compiler::TNode<JSArray> tmp62;
    compiler::TNode<JSArray> tmp63;
    compiler::TNode<Map> tmp64;
    compiler::TNode<BoolT> tmp65;
    compiler::TNode<BoolT> tmp66;
    compiler::TNode<BoolT> tmp67;
    compiler::TNode<Context> tmp68;
    ca_.Bind(&block5, &tmp56, &tmp57, &tmp58, &tmp59, &tmp60, &tmp61, &tmp62, &tmp63, &tmp64, &tmp65, &tmp66, &tmp67, &tmp68);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 16);
    compiler::TNode<Smi> tmp69;
    USE(tmp69);
    tmp69 = ca_.UncheckedCast<Smi>(CodeStubAssembler(state_).LoadFastJSArrayLength(compiler::TNode<JSArray>{tmp61}));
    compiler::TNode<Smi> tmp70;
    USE(tmp70);
    tmp70 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr5ATSmi17ATconstexpr_int31(0));
    compiler::TNode<BoolT> tmp71;
    USE(tmp71);
    tmp71 = ca_.UncheckedCast<BoolT>(CodeStubAssembler(state_).SmiEqual(compiler::TNode<Smi>{tmp69}, compiler::TNode<Smi>{tmp70}));
    ca_.Branch(tmp71, &block8, &block9, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp62, tmp63, tmp64, tmp65, tmp66, tmp67);
  }

  if (block8.is_used()) {
    compiler::TNode<Context> tmp72;
    compiler::TNode<Object> tmp73;
    compiler::TNode<RawPtrT> tmp74;
    compiler::TNode<RawPtrT> tmp75;
    compiler::TNode<IntPtrT> tmp76;
    compiler::TNode<JSArray> tmp77;
    compiler::TNode<JSArray> tmp78;
    compiler::TNode<JSArray> tmp79;
    compiler::TNode<Map> tmp80;
    compiler::TNode<BoolT> tmp81;
    compiler::TNode<BoolT> tmp82;
    compiler::TNode<BoolT> tmp83;
    ca_.Bind(&block8, &tmp72, &tmp73, &tmp74, &tmp75, &tmp76, &tmp77, &tmp78, &tmp79, &tmp80, &tmp81, &tmp82, &tmp83);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 17);
    compiler::TNode<Oddball> tmp84;
    USE(tmp84);
    tmp84 = BaseBuiltinsFromDSLAssembler(state_).Undefined();
    ca_.Goto(&block2, tmp72, tmp73, tmp74, tmp75, tmp76, tmp84);
  }

  if (block9.is_used()) {
    compiler::TNode<Context> tmp85;
    compiler::TNode<Object> tmp86;
    compiler::TNode<RawPtrT> tmp87;
    compiler::TNode<RawPtrT> tmp88;
    compiler::TNode<IntPtrT> tmp89;
    compiler::TNode<JSArray> tmp90;
    compiler::TNode<JSArray> tmp91;
    compiler::TNode<JSArray> tmp92;
    compiler::TNode<Map> tmp93;
    compiler::TNode<BoolT> tmp94;
    compiler::TNode<BoolT> tmp95;
    compiler::TNode<BoolT> tmp96;
    ca_.Bind(&block9, &tmp85, &tmp86, &tmp87, &tmp88, &tmp89, &tmp90, &tmp91, &tmp92, &tmp93, &tmp94, &tmp95, &tmp96);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 21);
    compiler::TNode<Smi> tmp97;
    USE(tmp97);
    tmp97 = ca_.UncheckedCast<Smi>(CodeStubAssembler(state_).LoadFastJSArrayLength(compiler::TNode<JSArray>{tmp90}));
    compiler::TNode<Smi> tmp98;
    USE(tmp98);
    tmp98 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr5ATSmi17ATconstexpr_int31(1));
    compiler::TNode<Smi> tmp99;
    USE(tmp99);
    tmp99 = ca_.UncheckedCast<Smi>(CodeStubAssembler(state_).SmiSub(compiler::TNode<Smi>{tmp97}, compiler::TNode<Smi>{tmp98}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 25);
    compiler::TNode<Smi> tmp100;
    USE(tmp100);
    tmp100 = ca_.UncheckedCast<Smi>(CodeStubAssembler(state_).SmiAdd(compiler::TNode<Smi>{tmp99}, compiler::TNode<Smi>{tmp99}));
    compiler::TNode<Smi> tmp101;
    USE(tmp101);
    tmp101 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr5ATSmi17ATconstexpr_int31(JSObject::kMinAddedElementsCapacity));
    compiler::TNode<Smi> tmp102;
    USE(tmp102);
    tmp102 = ca_.UncheckedCast<Smi>(CodeStubAssembler(state_).SmiAdd(compiler::TNode<Smi>{tmp100}, compiler::TNode<Smi>{tmp101}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 26);
    compiler::TNode<FixedArrayBase> tmp103;
    USE(tmp103);
    tmp103 = ca_.UncheckedCast<FixedArrayBase>(BaseBuiltinsFromDSLAssembler(state_).LoadJSObjectElements(compiler::TNode<JSObject>{tmp90}));
    compiler::TNode<Smi> tmp104;
    USE(tmp104);
    tmp104 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).LoadFixedArrayBaseLength(compiler::TNode<FixedArrayBase>{tmp103}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 25);
    compiler::TNode<BoolT> tmp105;
    USE(tmp105);
    tmp105 = ca_.UncheckedCast<BoolT>(CodeStubAssembler(state_).SmiLessThan(compiler::TNode<Smi>{tmp102}, compiler::TNode<Smi>{tmp104}));
    ca_.Branch(tmp105, &block12, &block13, tmp85, tmp86, tmp87, tmp88, tmp89, tmp90, tmp91, tmp92, tmp93, tmp94, tmp95, tmp96, tmp99);
  }

  if (block12.is_used()) {
    compiler::TNode<Context> tmp106;
    compiler::TNode<Object> tmp107;
    compiler::TNode<RawPtrT> tmp108;
    compiler::TNode<RawPtrT> tmp109;
    compiler::TNode<IntPtrT> tmp110;
    compiler::TNode<JSArray> tmp111;
    compiler::TNode<JSArray> tmp112;
    compiler::TNode<JSArray> tmp113;
    compiler::TNode<Map> tmp114;
    compiler::TNode<BoolT> tmp115;
    compiler::TNode<BoolT> tmp116;
    compiler::TNode<BoolT> tmp117;
    compiler::TNode<Smi> tmp118;
    ca_.Bind(&block12, &tmp106, &tmp107, &tmp108, &tmp109, &tmp110, &tmp111, &tmp112, &tmp113, &tmp114, &tmp115, &tmp116, &tmp117, &tmp118);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 27);
    ca_.Goto(&block11, tmp106, tmp107, tmp108, tmp109, tmp110, tmp111, tmp112, tmp113, tmp114, tmp115, tmp116, tmp117);
  }

  if (block13.is_used()) {
    compiler::TNode<Context> tmp119;
    compiler::TNode<Object> tmp120;
    compiler::TNode<RawPtrT> tmp121;
    compiler::TNode<RawPtrT> tmp122;
    compiler::TNode<IntPtrT> tmp123;
    compiler::TNode<JSArray> tmp124;
    compiler::TNode<JSArray> tmp125;
    compiler::TNode<JSArray> tmp126;
    compiler::TNode<Map> tmp127;
    compiler::TNode<BoolT> tmp128;
    compiler::TNode<BoolT> tmp129;
    compiler::TNode<BoolT> tmp130;
    compiler::TNode<Smi> tmp131;
    ca_.Bind(&block13, &tmp119, &tmp120, &tmp121, &tmp122, &tmp123, &tmp124, &tmp125, &tmp126, &tmp127, &tmp128, &tmp129, &tmp130, &tmp131);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 32);
    compiler::TNode<Smi> tmp132;
    USE(tmp132);
    tmp132 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr5ATSmi17ATconstexpr_int31(JSArray::kMaxCopyElements));
    compiler::TNode<BoolT> tmp133;
    USE(tmp133);
    tmp133 = ca_.UncheckedCast<BoolT>(CodeStubAssembler(state_).SmiGreaterThan(compiler::TNode<Smi>{tmp131}, compiler::TNode<Smi>{tmp132}));
    ca_.Branch(tmp133, &block14, &block15, tmp119, tmp120, tmp121, tmp122, tmp123, tmp124, tmp125, tmp126, tmp127, tmp128, tmp129, tmp130, tmp131);
  }

  if (block14.is_used()) {
    compiler::TNode<Context> tmp134;
    compiler::TNode<Object> tmp135;
    compiler::TNode<RawPtrT> tmp136;
    compiler::TNode<RawPtrT> tmp137;
    compiler::TNode<IntPtrT> tmp138;
    compiler::TNode<JSArray> tmp139;
    compiler::TNode<JSArray> tmp140;
    compiler::TNode<JSArray> tmp141;
    compiler::TNode<Map> tmp142;
    compiler::TNode<BoolT> tmp143;
    compiler::TNode<BoolT> tmp144;
    compiler::TNode<BoolT> tmp145;
    compiler::TNode<Smi> tmp146;
    ca_.Bind(&block14, &tmp134, &tmp135, &tmp136, &tmp137, &tmp138, &tmp139, &tmp140, &tmp141, &tmp142, &tmp143, &tmp144, &tmp145, &tmp146);
    ca_.Goto(&block11, tmp134, tmp135, tmp136, tmp137, tmp138, tmp139, tmp140, tmp141, tmp142, tmp143, tmp144, tmp145);
  }

  if (block15.is_used()) {
    compiler::TNode<Context> tmp147;
    compiler::TNode<Object> tmp148;
    compiler::TNode<RawPtrT> tmp149;
    compiler::TNode<RawPtrT> tmp150;
    compiler::TNode<IntPtrT> tmp151;
    compiler::TNode<JSArray> tmp152;
    compiler::TNode<JSArray> tmp153;
    compiler::TNode<JSArray> tmp154;
    compiler::TNode<Map> tmp155;
    compiler::TNode<BoolT> tmp156;
    compiler::TNode<BoolT> tmp157;
    compiler::TNode<BoolT> tmp158;
    compiler::TNode<Smi> tmp159;
    ca_.Bind(&block15, &tmp147, &tmp148, &tmp149, &tmp150, &tmp151, &tmp152, &tmp153, &tmp154, &tmp155, &tmp156, &tmp157, &tmp158, &tmp159);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 34);
    compiler::TNode<Smi> tmp160;
    USE(tmp160);
    tmp160 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr5ATSmi17ATconstexpr_int31(0));
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2015);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2004);
    ca_.Branch(tmp156, &block20, &block21, tmp147, tmp148, tmp149, tmp150, tmp151, tmp152, tmp153, tmp154, tmp155, tmp156, tmp157, tmp158, tmp159, tmp147, tmp160, tmp160, tmp147, tmp160);
  }

  if (block20.is_used()) {
    compiler::TNode<Context> tmp161;
    compiler::TNode<Object> tmp162;
    compiler::TNode<RawPtrT> tmp163;
    compiler::TNode<RawPtrT> tmp164;
    compiler::TNode<IntPtrT> tmp165;
    compiler::TNode<JSArray> tmp166;
    compiler::TNode<JSArray> tmp167;
    compiler::TNode<JSArray> tmp168;
    compiler::TNode<Map> tmp169;
    compiler::TNode<BoolT> tmp170;
    compiler::TNode<BoolT> tmp171;
    compiler::TNode<BoolT> tmp172;
    compiler::TNode<Smi> tmp173;
    compiler::TNode<Context> tmp174;
    compiler::TNode<Smi> tmp175;
    compiler::TNode<Smi> tmp176;
    compiler::TNode<Context> tmp177;
    compiler::TNode<Smi> tmp178;
    ca_.Bind(&block20, &tmp161, &tmp162, &tmp163, &tmp164, &tmp165, &tmp166, &tmp167, &tmp168, &tmp169, &tmp170, &tmp171, &tmp172, &tmp173, &tmp174, &tmp175, &tmp176, &tmp177, &tmp178);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2005);
    compiler::TNode<Object> tmp179;
    USE(tmp179);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp179 = BaseBuiltinsFromDSLAssembler(state_).LoadElementNoHole16FixedDoubleArray(compiler::TNode<Context>{tmp177}, compiler::TNode<JSArray>{tmp168}, compiler::TNode<Smi>{tmp178}, &label0);
    ca_.Goto(&block23, tmp161, tmp162, tmp163, tmp164, tmp165, tmp166, tmp167, tmp168, tmp169, tmp170, tmp171, tmp172, tmp173, tmp174, tmp175, tmp176, tmp177, tmp178, tmp168, tmp178, tmp179);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block24, tmp161, tmp162, tmp163, tmp164, tmp165, tmp166, tmp167, tmp168, tmp169, tmp170, tmp171, tmp172, tmp173, tmp174, tmp175, tmp176, tmp177, tmp178, tmp168, tmp178);
    }
  }

  if (block24.is_used()) {
    compiler::TNode<Context> tmp180;
    compiler::TNode<Object> tmp181;
    compiler::TNode<RawPtrT> tmp182;
    compiler::TNode<RawPtrT> tmp183;
    compiler::TNode<IntPtrT> tmp184;
    compiler::TNode<JSArray> tmp185;
    compiler::TNode<JSArray> tmp186;
    compiler::TNode<JSArray> tmp187;
    compiler::TNode<Map> tmp188;
    compiler::TNode<BoolT> tmp189;
    compiler::TNode<BoolT> tmp190;
    compiler::TNode<BoolT> tmp191;
    compiler::TNode<Smi> tmp192;
    compiler::TNode<Context> tmp193;
    compiler::TNode<Smi> tmp194;
    compiler::TNode<Smi> tmp195;
    compiler::TNode<Context> tmp196;
    compiler::TNode<Smi> tmp197;
    compiler::TNode<JSArray> tmp198;
    compiler::TNode<Smi> tmp199;
    ca_.Bind(&block24, &tmp180, &tmp181, &tmp182, &tmp183, &tmp184, &tmp185, &tmp186, &tmp187, &tmp188, &tmp189, &tmp190, &tmp191, &tmp192, &tmp193, &tmp194, &tmp195, &tmp196, &tmp197, &tmp198, &tmp199);
    ca_.Goto(&block18, tmp180, tmp181, tmp182, tmp183, tmp184, tmp185, tmp186, tmp187, tmp188, tmp189, tmp190, tmp191, tmp192, tmp193, tmp194);
  }

  if (block23.is_used()) {
    compiler::TNode<Context> tmp200;
    compiler::TNode<Object> tmp201;
    compiler::TNode<RawPtrT> tmp202;
    compiler::TNode<RawPtrT> tmp203;
    compiler::TNode<IntPtrT> tmp204;
    compiler::TNode<JSArray> tmp205;
    compiler::TNode<JSArray> tmp206;
    compiler::TNode<JSArray> tmp207;
    compiler::TNode<Map> tmp208;
    compiler::TNode<BoolT> tmp209;
    compiler::TNode<BoolT> tmp210;
    compiler::TNode<BoolT> tmp211;
    compiler::TNode<Smi> tmp212;
    compiler::TNode<Context> tmp213;
    compiler::TNode<Smi> tmp214;
    compiler::TNode<Smi> tmp215;
    compiler::TNode<Context> tmp216;
    compiler::TNode<Smi> tmp217;
    compiler::TNode<JSArray> tmp218;
    compiler::TNode<Smi> tmp219;
    compiler::TNode<Object> tmp220;
    ca_.Bind(&block23, &tmp200, &tmp201, &tmp202, &tmp203, &tmp204, &tmp205, &tmp206, &tmp207, &tmp208, &tmp209, &tmp210, &tmp211, &tmp212, &tmp213, &tmp214, &tmp215, &tmp216, &tmp217, &tmp218, &tmp219, &tmp220);
    ca_.Goto(&block19, tmp200, tmp201, tmp202, tmp203, tmp204, tmp205, tmp206, tmp207, tmp208, tmp209, tmp210, tmp211, tmp212, tmp213, tmp214, tmp215, tmp216, tmp217, tmp220);
  }

  if (block21.is_used()) {
    compiler::TNode<Context> tmp221;
    compiler::TNode<Object> tmp222;
    compiler::TNode<RawPtrT> tmp223;
    compiler::TNode<RawPtrT> tmp224;
    compiler::TNode<IntPtrT> tmp225;
    compiler::TNode<JSArray> tmp226;
    compiler::TNode<JSArray> tmp227;
    compiler::TNode<JSArray> tmp228;
    compiler::TNode<Map> tmp229;
    compiler::TNode<BoolT> tmp230;
    compiler::TNode<BoolT> tmp231;
    compiler::TNode<BoolT> tmp232;
    compiler::TNode<Smi> tmp233;
    compiler::TNode<Context> tmp234;
    compiler::TNode<Smi> tmp235;
    compiler::TNode<Smi> tmp236;
    compiler::TNode<Context> tmp237;
    compiler::TNode<Smi> tmp238;
    ca_.Bind(&block21, &tmp221, &tmp222, &tmp223, &tmp224, &tmp225, &tmp226, &tmp227, &tmp228, &tmp229, &tmp230, &tmp231, &tmp232, &tmp233, &tmp234, &tmp235, &tmp236, &tmp237, &tmp238);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2008);
    compiler::TNode<Object> tmp239;
    USE(tmp239);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp239 = BaseBuiltinsFromDSLAssembler(state_).LoadElementNoHole10FixedArray(compiler::TNode<Context>{tmp237}, compiler::TNode<JSArray>{tmp228}, compiler::TNode<Smi>{tmp238}, &label0);
    ca_.Goto(&block25, tmp221, tmp222, tmp223, tmp224, tmp225, tmp226, tmp227, tmp228, tmp229, tmp230, tmp231, tmp232, tmp233, tmp234, tmp235, tmp236, tmp237, tmp238, tmp228, tmp238, tmp239);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block26, tmp221, tmp222, tmp223, tmp224, tmp225, tmp226, tmp227, tmp228, tmp229, tmp230, tmp231, tmp232, tmp233, tmp234, tmp235, tmp236, tmp237, tmp238, tmp228, tmp238);
    }
  }

  if (block26.is_used()) {
    compiler::TNode<Context> tmp240;
    compiler::TNode<Object> tmp241;
    compiler::TNode<RawPtrT> tmp242;
    compiler::TNode<RawPtrT> tmp243;
    compiler::TNode<IntPtrT> tmp244;
    compiler::TNode<JSArray> tmp245;
    compiler::TNode<JSArray> tmp246;
    compiler::TNode<JSArray> tmp247;
    compiler::TNode<Map> tmp248;
    compiler::TNode<BoolT> tmp249;
    compiler::TNode<BoolT> tmp250;
    compiler::TNode<BoolT> tmp251;
    compiler::TNode<Smi> tmp252;
    compiler::TNode<Context> tmp253;
    compiler::TNode<Smi> tmp254;
    compiler::TNode<Smi> tmp255;
    compiler::TNode<Context> tmp256;
    compiler::TNode<Smi> tmp257;
    compiler::TNode<JSArray> tmp258;
    compiler::TNode<Smi> tmp259;
    ca_.Bind(&block26, &tmp240, &tmp241, &tmp242, &tmp243, &tmp244, &tmp245, &tmp246, &tmp247, &tmp248, &tmp249, &tmp250, &tmp251, &tmp252, &tmp253, &tmp254, &tmp255, &tmp256, &tmp257, &tmp258, &tmp259);
    ca_.Goto(&block18, tmp240, tmp241, tmp242, tmp243, tmp244, tmp245, tmp246, tmp247, tmp248, tmp249, tmp250, tmp251, tmp252, tmp253, tmp254);
  }

  if (block25.is_used()) {
    compiler::TNode<Context> tmp260;
    compiler::TNode<Object> tmp261;
    compiler::TNode<RawPtrT> tmp262;
    compiler::TNode<RawPtrT> tmp263;
    compiler::TNode<IntPtrT> tmp264;
    compiler::TNode<JSArray> tmp265;
    compiler::TNode<JSArray> tmp266;
    compiler::TNode<JSArray> tmp267;
    compiler::TNode<Map> tmp268;
    compiler::TNode<BoolT> tmp269;
    compiler::TNode<BoolT> tmp270;
    compiler::TNode<BoolT> tmp271;
    compiler::TNode<Smi> tmp272;
    compiler::TNode<Context> tmp273;
    compiler::TNode<Smi> tmp274;
    compiler::TNode<Smi> tmp275;
    compiler::TNode<Context> tmp276;
    compiler::TNode<Smi> tmp277;
    compiler::TNode<JSArray> tmp278;
    compiler::TNode<Smi> tmp279;
    compiler::TNode<Object> tmp280;
    ca_.Bind(&block25, &tmp260, &tmp261, &tmp262, &tmp263, &tmp264, &tmp265, &tmp266, &tmp267, &tmp268, &tmp269, &tmp270, &tmp271, &tmp272, &tmp273, &tmp274, &tmp275, &tmp276, &tmp277, &tmp278, &tmp279, &tmp280);
    ca_.Goto(&block19, tmp260, tmp261, tmp262, tmp263, tmp264, tmp265, tmp266, tmp267, tmp268, tmp269, tmp270, tmp271, tmp272, tmp273, tmp274, tmp275, tmp276, tmp277, tmp280);
  }

  if (block19.is_used()) {
    compiler::TNode<Context> tmp281;
    compiler::TNode<Object> tmp282;
    compiler::TNode<RawPtrT> tmp283;
    compiler::TNode<RawPtrT> tmp284;
    compiler::TNode<IntPtrT> tmp285;
    compiler::TNode<JSArray> tmp286;
    compiler::TNode<JSArray> tmp287;
    compiler::TNode<JSArray> tmp288;
    compiler::TNode<Map> tmp289;
    compiler::TNode<BoolT> tmp290;
    compiler::TNode<BoolT> tmp291;
    compiler::TNode<BoolT> tmp292;
    compiler::TNode<Smi> tmp293;
    compiler::TNode<Context> tmp294;
    compiler::TNode<Smi> tmp295;
    compiler::TNode<Smi> tmp296;
    compiler::TNode<Context> tmp297;
    compiler::TNode<Smi> tmp298;
    compiler::TNode<Object> tmp299;
    ca_.Bind(&block19, &tmp281, &tmp282, &tmp283, &tmp284, &tmp285, &tmp286, &tmp287, &tmp288, &tmp289, &tmp290, &tmp291, &tmp292, &tmp293, &tmp294, &tmp295, &tmp296, &tmp297, &tmp298, &tmp299);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2015);
    ca_.Goto(&block16, tmp281, tmp282, tmp283, tmp284, tmp285, tmp286, tmp287, tmp288, tmp289, tmp290, tmp291, tmp292, tmp293, tmp294, tmp295, tmp299);
  }

  if (block18.is_used()) {
    compiler::TNode<Context> tmp300;
    compiler::TNode<Object> tmp301;
    compiler::TNode<RawPtrT> tmp302;
    compiler::TNode<RawPtrT> tmp303;
    compiler::TNode<IntPtrT> tmp304;
    compiler::TNode<JSArray> tmp305;
    compiler::TNode<JSArray> tmp306;
    compiler::TNode<JSArray> tmp307;
    compiler::TNode<Map> tmp308;
    compiler::TNode<BoolT> tmp309;
    compiler::TNode<BoolT> tmp310;
    compiler::TNode<BoolT> tmp311;
    compiler::TNode<Smi> tmp312;
    compiler::TNode<Context> tmp313;
    compiler::TNode<Smi> tmp314;
    ca_.Bind(&block18, &tmp300, &tmp301, &tmp302, &tmp303, &tmp304, &tmp305, &tmp306, &tmp307, &tmp308, &tmp309, &tmp310, &tmp311, &tmp312, &tmp313, &tmp314);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2018);
    compiler::TNode<Oddball> tmp315;
    USE(tmp315);
    tmp315 = BaseBuiltinsFromDSLAssembler(state_).Undefined();
    ca_.Goto(&block16, tmp300, tmp301, tmp302, tmp303, tmp304, tmp305, tmp306, tmp307, tmp308, tmp309, tmp310, tmp311, tmp312, tmp313, tmp314, tmp315);
  }

  if (block16.is_used()) {
    compiler::TNode<Context> tmp316;
    compiler::TNode<Object> tmp317;
    compiler::TNode<RawPtrT> tmp318;
    compiler::TNode<RawPtrT> tmp319;
    compiler::TNode<IntPtrT> tmp320;
    compiler::TNode<JSArray> tmp321;
    compiler::TNode<JSArray> tmp322;
    compiler::TNode<JSArray> tmp323;
    compiler::TNode<Map> tmp324;
    compiler::TNode<BoolT> tmp325;
    compiler::TNode<BoolT> tmp326;
    compiler::TNode<BoolT> tmp327;
    compiler::TNode<Smi> tmp328;
    compiler::TNode<Context> tmp329;
    compiler::TNode<Smi> tmp330;
    compiler::TNode<Object> tmp331;
    ca_.Bind(&block16, &tmp316, &tmp317, &tmp318, &tmp319, &tmp320, &tmp321, &tmp322, &tmp323, &tmp324, &tmp325, &tmp326, &tmp327, &tmp328, &tmp329, &tmp330, &tmp331);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 34);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 35);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2030);
    BaseBuiltinsFromDSLAssembler(state_).StoreJSArrayLength(compiler::TNode<JSArray>{tmp323}, compiler::TNode<Number>{tmp328});
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 35);
    ca_.Goto(&block27, tmp316, tmp317, tmp318, tmp319, tmp320, tmp321, tmp322, tmp323, tmp324, tmp325, tmp326, tmp327, tmp328, tmp331, tmp328, tmp328);
  }

  if (block27.is_used()) {
    compiler::TNode<Context> tmp332;
    compiler::TNode<Object> tmp333;
    compiler::TNode<RawPtrT> tmp334;
    compiler::TNode<RawPtrT> tmp335;
    compiler::TNode<IntPtrT> tmp336;
    compiler::TNode<JSArray> tmp337;
    compiler::TNode<JSArray> tmp338;
    compiler::TNode<JSArray> tmp339;
    compiler::TNode<Map> tmp340;
    compiler::TNode<BoolT> tmp341;
    compiler::TNode<BoolT> tmp342;
    compiler::TNode<BoolT> tmp343;
    compiler::TNode<Smi> tmp344;
    compiler::TNode<Object> tmp345;
    compiler::TNode<Smi> tmp346;
    compiler::TNode<Smi> tmp347;
    ca_.Bind(&block27, &tmp332, &tmp333, &tmp334, &tmp335, &tmp336, &tmp337, &tmp338, &tmp339, &tmp340, &tmp341, &tmp342, &tmp343, &tmp344, &tmp345, &tmp346, &tmp347);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 36);
    compiler::TNode<IntPtrT> tmp348;
    USE(tmp348);
    tmp348 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).Convert8ATintptr5ATSmi(compiler::TNode<Smi>{tmp344}));
    compiler::TNode<IntPtrT> tmp349;
    USE(tmp349);
    tmp349 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr8ATintptr17ATconstexpr_int31(0));
    compiler::TNode<IntPtrT> tmp350;
    USE(tmp350);
    tmp350 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr8ATintptr17ATconstexpr_int31(1));
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2052);
    ca_.Branch(tmp341, &block29, &block30, tmp332, tmp333, tmp334, tmp335, tmp336, tmp337, tmp338, tmp339, tmp340, tmp341, tmp342, tmp343, tmp344, tmp345, tmp348, tmp349, tmp350, tmp348);
  }

  if (block29.is_used()) {
    compiler::TNode<Context> tmp351;
    compiler::TNode<Object> tmp352;
    compiler::TNode<RawPtrT> tmp353;
    compiler::TNode<RawPtrT> tmp354;
    compiler::TNode<IntPtrT> tmp355;
    compiler::TNode<JSArray> tmp356;
    compiler::TNode<JSArray> tmp357;
    compiler::TNode<JSArray> tmp358;
    compiler::TNode<Map> tmp359;
    compiler::TNode<BoolT> tmp360;
    compiler::TNode<BoolT> tmp361;
    compiler::TNode<BoolT> tmp362;
    compiler::TNode<Smi> tmp363;
    compiler::TNode<Object> tmp364;
    compiler::TNode<IntPtrT> tmp365;
    compiler::TNode<IntPtrT> tmp366;
    compiler::TNode<IntPtrT> tmp367;
    compiler::TNode<IntPtrT> tmp368;
    ca_.Bind(&block29, &tmp351, &tmp352, &tmp353, &tmp354, &tmp355, &tmp356, &tmp357, &tmp358, &tmp359, &tmp360, &tmp361, &tmp362, &tmp363, &tmp364, &tmp365, &tmp366, &tmp367, &tmp368);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2054);
    compiler::TNode<FixedArrayBase> tmp369;
    USE(tmp369);
    tmp369 = ca_.UncheckedCast<FixedArrayBase>(BaseBuiltinsFromDSLAssembler(state_).LoadJSObjectElements(compiler::TNode<JSObject>{tmp358}));
    compiler::TNode<FixedDoubleArray> tmp370;
    USE(tmp370);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp370 = BaseBuiltinsFromDSLAssembler(state_).Cast16FixedDoubleArray(compiler::TNode<HeapObject>{tmp369}, &label0);
    ca_.Goto(&block34, tmp351, tmp352, tmp353, tmp354, tmp355, tmp356, tmp357, tmp358, tmp359, tmp360, tmp361, tmp362, tmp363, tmp364, tmp365, tmp366, tmp367, tmp368, tmp369, tmp370);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block35, tmp351, tmp352, tmp353, tmp354, tmp355, tmp356, tmp357, tmp358, tmp359, tmp360, tmp361, tmp362, tmp363, tmp364, tmp365, tmp366, tmp367, tmp368, tmp369);
    }
  }

  if (block35.is_used()) {
    compiler::TNode<Context> tmp371;
    compiler::TNode<Object> tmp372;
    compiler::TNode<RawPtrT> tmp373;
    compiler::TNode<RawPtrT> tmp374;
    compiler::TNode<IntPtrT> tmp375;
    compiler::TNode<JSArray> tmp376;
    compiler::TNode<JSArray> tmp377;
    compiler::TNode<JSArray> tmp378;
    compiler::TNode<Map> tmp379;
    compiler::TNode<BoolT> tmp380;
    compiler::TNode<BoolT> tmp381;
    compiler::TNode<BoolT> tmp382;
    compiler::TNode<Smi> tmp383;
    compiler::TNode<Object> tmp384;
    compiler::TNode<IntPtrT> tmp385;
    compiler::TNode<IntPtrT> tmp386;
    compiler::TNode<IntPtrT> tmp387;
    compiler::TNode<IntPtrT> tmp388;
    compiler::TNode<FixedArrayBase> tmp389;
    ca_.Bind(&block35, &tmp371, &tmp372, &tmp373, &tmp374, &tmp375, &tmp376, &tmp377, &tmp378, &tmp379, &tmp380, &tmp381, &tmp382, &tmp383, &tmp384, &tmp385, &tmp386, &tmp387, &tmp388, &tmp389);
    ca_.Goto(&block33, tmp371, tmp372, tmp373, tmp374, tmp375, tmp376, tmp377, tmp378, tmp379, tmp380, tmp381, tmp382, tmp383, tmp384, tmp385, tmp386, tmp387, tmp388);
  }

  if (block34.is_used()) {
    compiler::TNode<Context> tmp390;
    compiler::TNode<Object> tmp391;
    compiler::TNode<RawPtrT> tmp392;
    compiler::TNode<RawPtrT> tmp393;
    compiler::TNode<IntPtrT> tmp394;
    compiler::TNode<JSArray> tmp395;
    compiler::TNode<JSArray> tmp396;
    compiler::TNode<JSArray> tmp397;
    compiler::TNode<Map> tmp398;
    compiler::TNode<BoolT> tmp399;
    compiler::TNode<BoolT> tmp400;
    compiler::TNode<BoolT> tmp401;
    compiler::TNode<Smi> tmp402;
    compiler::TNode<Object> tmp403;
    compiler::TNode<IntPtrT> tmp404;
    compiler::TNode<IntPtrT> tmp405;
    compiler::TNode<IntPtrT> tmp406;
    compiler::TNode<IntPtrT> tmp407;
    compiler::TNode<FixedArrayBase> tmp408;
    compiler::TNode<FixedDoubleArray> tmp409;
    ca_.Bind(&block34, &tmp390, &tmp391, &tmp392, &tmp393, &tmp394, &tmp395, &tmp396, &tmp397, &tmp398, &tmp399, &tmp400, &tmp401, &tmp402, &tmp403, &tmp404, &tmp405, &tmp406, &tmp407, &tmp408, &tmp409);
    ca_.Goto(&block32, tmp390, tmp391, tmp392, tmp393, tmp394, tmp395, tmp396, tmp397, tmp398, tmp399, tmp400, tmp401, tmp402, tmp403, tmp404, tmp405, tmp406, tmp407, tmp409);
  }

  if (block33.is_used()) {
    compiler::TNode<Context> tmp410;
    compiler::TNode<Object> tmp411;
    compiler::TNode<RawPtrT> tmp412;
    compiler::TNode<RawPtrT> tmp413;
    compiler::TNode<IntPtrT> tmp414;
    compiler::TNode<JSArray> tmp415;
    compiler::TNode<JSArray> tmp416;
    compiler::TNode<JSArray> tmp417;
    compiler::TNode<Map> tmp418;
    compiler::TNode<BoolT> tmp419;
    compiler::TNode<BoolT> tmp420;
    compiler::TNode<BoolT> tmp421;
    compiler::TNode<Smi> tmp422;
    compiler::TNode<Object> tmp423;
    compiler::TNode<IntPtrT> tmp424;
    compiler::TNode<IntPtrT> tmp425;
    compiler::TNode<IntPtrT> tmp426;
    compiler::TNode<IntPtrT> tmp427;
    ca_.Bind(&block33, &tmp410, &tmp411, &tmp412, &tmp413, &tmp414, &tmp415, &tmp416, &tmp417, &tmp418, &tmp419, &tmp420, &tmp421, &tmp422, &tmp423, &tmp424, &tmp425, &tmp426, &tmp427);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2055);
    CodeStubAssembler(state_).Unreachable();
  }

  if (block32.is_used()) {
    compiler::TNode<Context> tmp428;
    compiler::TNode<Object> tmp429;
    compiler::TNode<RawPtrT> tmp430;
    compiler::TNode<RawPtrT> tmp431;
    compiler::TNode<IntPtrT> tmp432;
    compiler::TNode<JSArray> tmp433;
    compiler::TNode<JSArray> tmp434;
    compiler::TNode<JSArray> tmp435;
    compiler::TNode<Map> tmp436;
    compiler::TNode<BoolT> tmp437;
    compiler::TNode<BoolT> tmp438;
    compiler::TNode<BoolT> tmp439;
    compiler::TNode<Smi> tmp440;
    compiler::TNode<Object> tmp441;
    compiler::TNode<IntPtrT> tmp442;
    compiler::TNode<IntPtrT> tmp443;
    compiler::TNode<IntPtrT> tmp444;
    compiler::TNode<IntPtrT> tmp445;
    compiler::TNode<FixedDoubleArray> tmp446;
    ca_.Bind(&block32, &tmp428, &tmp429, &tmp430, &tmp431, &tmp432, &tmp433, &tmp434, &tmp435, &tmp436, &tmp437, &tmp438, &tmp439, &tmp440, &tmp441, &tmp442, &tmp443, &tmp444, &tmp445, &tmp446);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2053);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2056);
    BaseBuiltinsFromDSLAssembler(state_).TorqueMoveElements(compiler::TNode<FixedDoubleArray>{tmp446}, compiler::TNode<IntPtrT>{tmp443}, compiler::TNode<IntPtrT>{tmp444}, compiler::TNode<IntPtrT>{tmp445});
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2052);
    ca_.Goto(&block31, tmp428, tmp429, tmp430, tmp431, tmp432, tmp433, tmp434, tmp435, tmp436, tmp437, tmp438, tmp439, tmp440, tmp441, tmp442, tmp443, tmp444, tmp445);
  }

  if (block30.is_used()) {
    compiler::TNode<Context> tmp447;
    compiler::TNode<Object> tmp448;
    compiler::TNode<RawPtrT> tmp449;
    compiler::TNode<RawPtrT> tmp450;
    compiler::TNode<IntPtrT> tmp451;
    compiler::TNode<JSArray> tmp452;
    compiler::TNode<JSArray> tmp453;
    compiler::TNode<JSArray> tmp454;
    compiler::TNode<Map> tmp455;
    compiler::TNode<BoolT> tmp456;
    compiler::TNode<BoolT> tmp457;
    compiler::TNode<BoolT> tmp458;
    compiler::TNode<Smi> tmp459;
    compiler::TNode<Object> tmp460;
    compiler::TNode<IntPtrT> tmp461;
    compiler::TNode<IntPtrT> tmp462;
    compiler::TNode<IntPtrT> tmp463;
    compiler::TNode<IntPtrT> tmp464;
    ca_.Bind(&block30, &tmp447, &tmp448, &tmp449, &tmp450, &tmp451, &tmp452, &tmp453, &tmp454, &tmp455, &tmp456, &tmp457, &tmp458, &tmp459, &tmp460, &tmp461, &tmp462, &tmp463, &tmp464);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2058);
    compiler::TNode<FixedArrayBase> tmp465;
    USE(tmp465);
    tmp465 = ca_.UncheckedCast<FixedArrayBase>(BaseBuiltinsFromDSLAssembler(state_).LoadJSObjectElements(compiler::TNode<JSObject>{tmp454}));
    compiler::TNode<FixedArray> tmp466;
    USE(tmp466);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp466 = BaseBuiltinsFromDSLAssembler(state_).Cast10FixedArray(compiler::TNode<HeapObject>{tmp465}, &label0);
    ca_.Goto(&block38, tmp447, tmp448, tmp449, tmp450, tmp451, tmp452, tmp453, tmp454, tmp455, tmp456, tmp457, tmp458, tmp459, tmp460, tmp461, tmp462, tmp463, tmp464, tmp465, tmp466);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block39, tmp447, tmp448, tmp449, tmp450, tmp451, tmp452, tmp453, tmp454, tmp455, tmp456, tmp457, tmp458, tmp459, tmp460, tmp461, tmp462, tmp463, tmp464, tmp465);
    }
  }

  if (block39.is_used()) {
    compiler::TNode<Context> tmp467;
    compiler::TNode<Object> tmp468;
    compiler::TNode<RawPtrT> tmp469;
    compiler::TNode<RawPtrT> tmp470;
    compiler::TNode<IntPtrT> tmp471;
    compiler::TNode<JSArray> tmp472;
    compiler::TNode<JSArray> tmp473;
    compiler::TNode<JSArray> tmp474;
    compiler::TNode<Map> tmp475;
    compiler::TNode<BoolT> tmp476;
    compiler::TNode<BoolT> tmp477;
    compiler::TNode<BoolT> tmp478;
    compiler::TNode<Smi> tmp479;
    compiler::TNode<Object> tmp480;
    compiler::TNode<IntPtrT> tmp481;
    compiler::TNode<IntPtrT> tmp482;
    compiler::TNode<IntPtrT> tmp483;
    compiler::TNode<IntPtrT> tmp484;
    compiler::TNode<FixedArrayBase> tmp485;
    ca_.Bind(&block39, &tmp467, &tmp468, &tmp469, &tmp470, &tmp471, &tmp472, &tmp473, &tmp474, &tmp475, &tmp476, &tmp477, &tmp478, &tmp479, &tmp480, &tmp481, &tmp482, &tmp483, &tmp484, &tmp485);
    ca_.Goto(&block37, tmp467, tmp468, tmp469, tmp470, tmp471, tmp472, tmp473, tmp474, tmp475, tmp476, tmp477, tmp478, tmp479, tmp480, tmp481, tmp482, tmp483, tmp484);
  }

  if (block38.is_used()) {
    compiler::TNode<Context> tmp486;
    compiler::TNode<Object> tmp487;
    compiler::TNode<RawPtrT> tmp488;
    compiler::TNode<RawPtrT> tmp489;
    compiler::TNode<IntPtrT> tmp490;
    compiler::TNode<JSArray> tmp491;
    compiler::TNode<JSArray> tmp492;
    compiler::TNode<JSArray> tmp493;
    compiler::TNode<Map> tmp494;
    compiler::TNode<BoolT> tmp495;
    compiler::TNode<BoolT> tmp496;
    compiler::TNode<BoolT> tmp497;
    compiler::TNode<Smi> tmp498;
    compiler::TNode<Object> tmp499;
    compiler::TNode<IntPtrT> tmp500;
    compiler::TNode<IntPtrT> tmp501;
    compiler::TNode<IntPtrT> tmp502;
    compiler::TNode<IntPtrT> tmp503;
    compiler::TNode<FixedArrayBase> tmp504;
    compiler::TNode<FixedArray> tmp505;
    ca_.Bind(&block38, &tmp486, &tmp487, &tmp488, &tmp489, &tmp490, &tmp491, &tmp492, &tmp493, &tmp494, &tmp495, &tmp496, &tmp497, &tmp498, &tmp499, &tmp500, &tmp501, &tmp502, &tmp503, &tmp504, &tmp505);
    ca_.Goto(&block36, tmp486, tmp487, tmp488, tmp489, tmp490, tmp491, tmp492, tmp493, tmp494, tmp495, tmp496, tmp497, tmp498, tmp499, tmp500, tmp501, tmp502, tmp503, tmp505);
  }

  if (block37.is_used()) {
    compiler::TNode<Context> tmp506;
    compiler::TNode<Object> tmp507;
    compiler::TNode<RawPtrT> tmp508;
    compiler::TNode<RawPtrT> tmp509;
    compiler::TNode<IntPtrT> tmp510;
    compiler::TNode<JSArray> tmp511;
    compiler::TNode<JSArray> tmp512;
    compiler::TNode<JSArray> tmp513;
    compiler::TNode<Map> tmp514;
    compiler::TNode<BoolT> tmp515;
    compiler::TNode<BoolT> tmp516;
    compiler::TNode<BoolT> tmp517;
    compiler::TNode<Smi> tmp518;
    compiler::TNode<Object> tmp519;
    compiler::TNode<IntPtrT> tmp520;
    compiler::TNode<IntPtrT> tmp521;
    compiler::TNode<IntPtrT> tmp522;
    compiler::TNode<IntPtrT> tmp523;
    ca_.Bind(&block37, &tmp506, &tmp507, &tmp508, &tmp509, &tmp510, &tmp511, &tmp512, &tmp513, &tmp514, &tmp515, &tmp516, &tmp517, &tmp518, &tmp519, &tmp520, &tmp521, &tmp522, &tmp523);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2059);
    CodeStubAssembler(state_).Unreachable();
  }

  if (block36.is_used()) {
    compiler::TNode<Context> tmp524;
    compiler::TNode<Object> tmp525;
    compiler::TNode<RawPtrT> tmp526;
    compiler::TNode<RawPtrT> tmp527;
    compiler::TNode<IntPtrT> tmp528;
    compiler::TNode<JSArray> tmp529;
    compiler::TNode<JSArray> tmp530;
    compiler::TNode<JSArray> tmp531;
    compiler::TNode<Map> tmp532;
    compiler::TNode<BoolT> tmp533;
    compiler::TNode<BoolT> tmp534;
    compiler::TNode<BoolT> tmp535;
    compiler::TNode<Smi> tmp536;
    compiler::TNode<Object> tmp537;
    compiler::TNode<IntPtrT> tmp538;
    compiler::TNode<IntPtrT> tmp539;
    compiler::TNode<IntPtrT> tmp540;
    compiler::TNode<IntPtrT> tmp541;
    compiler::TNode<FixedArray> tmp542;
    ca_.Bind(&block36, &tmp524, &tmp525, &tmp526, &tmp527, &tmp528, &tmp529, &tmp530, &tmp531, &tmp532, &tmp533, &tmp534, &tmp535, &tmp536, &tmp537, &tmp538, &tmp539, &tmp540, &tmp541, &tmp542);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2058);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2060);
    ca_.Branch(tmp534, &block40, &block41, tmp524, tmp525, tmp526, tmp527, tmp528, tmp529, tmp530, tmp531, tmp532, tmp533, tmp534, tmp535, tmp536, tmp537, tmp538, tmp539, tmp540, tmp541, tmp542);
  }

  if (block40.is_used()) {
    compiler::TNode<Context> tmp543;
    compiler::TNode<Object> tmp544;
    compiler::TNode<RawPtrT> tmp545;
    compiler::TNode<RawPtrT> tmp546;
    compiler::TNode<IntPtrT> tmp547;
    compiler::TNode<JSArray> tmp548;
    compiler::TNode<JSArray> tmp549;
    compiler::TNode<JSArray> tmp550;
    compiler::TNode<Map> tmp551;
    compiler::TNode<BoolT> tmp552;
    compiler::TNode<BoolT> tmp553;
    compiler::TNode<BoolT> tmp554;
    compiler::TNode<Smi> tmp555;
    compiler::TNode<Object> tmp556;
    compiler::TNode<IntPtrT> tmp557;
    compiler::TNode<IntPtrT> tmp558;
    compiler::TNode<IntPtrT> tmp559;
    compiler::TNode<IntPtrT> tmp560;
    compiler::TNode<FixedArray> tmp561;
    ca_.Bind(&block40, &tmp543, &tmp544, &tmp545, &tmp546, &tmp547, &tmp548, &tmp549, &tmp550, &tmp551, &tmp552, &tmp553, &tmp554, &tmp555, &tmp556, &tmp557, &tmp558, &tmp559, &tmp560, &tmp561);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2061);
    BaseBuiltinsFromDSLAssembler(state_).TorqueMoveElementsSmi(compiler::TNode<FixedArray>{tmp561}, compiler::TNode<IntPtrT>{tmp558}, compiler::TNode<IntPtrT>{tmp559}, compiler::TNode<IntPtrT>{tmp560});
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2060);
    ca_.Goto(&block42, tmp543, tmp544, tmp545, tmp546, tmp547, tmp548, tmp549, tmp550, tmp551, tmp552, tmp553, tmp554, tmp555, tmp556, tmp557, tmp558, tmp559, tmp560, tmp561);
  }

  if (block41.is_used()) {
    compiler::TNode<Context> tmp562;
    compiler::TNode<Object> tmp563;
    compiler::TNode<RawPtrT> tmp564;
    compiler::TNode<RawPtrT> tmp565;
    compiler::TNode<IntPtrT> tmp566;
    compiler::TNode<JSArray> tmp567;
    compiler::TNode<JSArray> tmp568;
    compiler::TNode<JSArray> tmp569;
    compiler::TNode<Map> tmp570;
    compiler::TNode<BoolT> tmp571;
    compiler::TNode<BoolT> tmp572;
    compiler::TNode<BoolT> tmp573;
    compiler::TNode<Smi> tmp574;
    compiler::TNode<Object> tmp575;
    compiler::TNode<IntPtrT> tmp576;
    compiler::TNode<IntPtrT> tmp577;
    compiler::TNode<IntPtrT> tmp578;
    compiler::TNode<IntPtrT> tmp579;
    compiler::TNode<FixedArray> tmp580;
    ca_.Bind(&block41, &tmp562, &tmp563, &tmp564, &tmp565, &tmp566, &tmp567, &tmp568, &tmp569, &tmp570, &tmp571, &tmp572, &tmp573, &tmp574, &tmp575, &tmp576, &tmp577, &tmp578, &tmp579, &tmp580);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2063);
    BaseBuiltinsFromDSLAssembler(state_).TorqueMoveElements(compiler::TNode<FixedArray>{tmp580}, compiler::TNode<IntPtrT>{tmp577}, compiler::TNode<IntPtrT>{tmp578}, compiler::TNode<IntPtrT>{tmp579});
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2060);
    ca_.Goto(&block42, tmp562, tmp563, tmp564, tmp565, tmp566, tmp567, tmp568, tmp569, tmp570, tmp571, tmp572, tmp573, tmp574, tmp575, tmp576, tmp577, tmp578, tmp579, tmp580);
  }

  if (block42.is_used()) {
    compiler::TNode<Context> tmp581;
    compiler::TNode<Object> tmp582;
    compiler::TNode<RawPtrT> tmp583;
    compiler::TNode<RawPtrT> tmp584;
    compiler::TNode<IntPtrT> tmp585;
    compiler::TNode<JSArray> tmp586;
    compiler::TNode<JSArray> tmp587;
    compiler::TNode<JSArray> tmp588;
    compiler::TNode<Map> tmp589;
    compiler::TNode<BoolT> tmp590;
    compiler::TNode<BoolT> tmp591;
    compiler::TNode<BoolT> tmp592;
    compiler::TNode<Smi> tmp593;
    compiler::TNode<Object> tmp594;
    compiler::TNode<IntPtrT> tmp595;
    compiler::TNode<IntPtrT> tmp596;
    compiler::TNode<IntPtrT> tmp597;
    compiler::TNode<IntPtrT> tmp598;
    compiler::TNode<FixedArray> tmp599;
    ca_.Bind(&block42, &tmp581, &tmp582, &tmp583, &tmp584, &tmp585, &tmp586, &tmp587, &tmp588, &tmp589, &tmp590, &tmp591, &tmp592, &tmp593, &tmp594, &tmp595, &tmp596, &tmp597, &tmp598, &tmp599);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2057);
    ca_.SetSourcePosition("../../src/builtins/base.tq", 2052);
    ca_.Goto(&block31, tmp581, tmp582, tmp583, tmp584, tmp585, tmp586, tmp587, tmp588, tmp589, tmp590, tmp591, tmp592, tmp593, tmp594, tmp595, tmp596, tmp597, tmp598);
  }

  if (block31.is_used()) {
    compiler::TNode<Context> tmp600;
    compiler::TNode<Object> tmp601;
    compiler::TNode<RawPtrT> tmp602;
    compiler::TNode<RawPtrT> tmp603;
    compiler::TNode<IntPtrT> tmp604;
    compiler::TNode<JSArray> tmp605;
    compiler::TNode<JSArray> tmp606;
    compiler::TNode<JSArray> tmp607;
    compiler::TNode<Map> tmp608;
    compiler::TNode<BoolT> tmp609;
    compiler::TNode<BoolT> tmp610;
    compiler::TNode<BoolT> tmp611;
    compiler::TNode<Smi> tmp612;
    compiler::TNode<Object> tmp613;
    compiler::TNode<IntPtrT> tmp614;
    compiler::TNode<IntPtrT> tmp615;
    compiler::TNode<IntPtrT> tmp616;
    compiler::TNode<IntPtrT> tmp617;
    ca_.Bind(&block31, &tmp600, &tmp601, &tmp602, &tmp603, &tmp604, &tmp605, &tmp606, &tmp607, &tmp608, &tmp609, &tmp610, &tmp611, &tmp612, &tmp613, &tmp614, &tmp615, &tmp616, &tmp617);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 36);
    ca_.Goto(&block28, tmp600, tmp601, tmp602, tmp603, tmp604, tmp605, tmp606, tmp607, tmp608, tmp609, tmp610, tmp611, tmp612, tmp613, tmp614, tmp615, tmp616, tmp617);
  }

  if (block28.is_used()) {
    compiler::TNode<Context> tmp618;
    compiler::TNode<Object> tmp619;
    compiler::TNode<RawPtrT> tmp620;
    compiler::TNode<RawPtrT> tmp621;
    compiler::TNode<IntPtrT> tmp622;
    compiler::TNode<JSArray> tmp623;
    compiler::TNode<JSArray> tmp624;
    compiler::TNode<JSArray> tmp625;
    compiler::TNode<Map> tmp626;
    compiler::TNode<BoolT> tmp627;
    compiler::TNode<BoolT> tmp628;
    compiler::TNode<BoolT> tmp629;
    compiler::TNode<Smi> tmp630;
    compiler::TNode<Object> tmp631;
    compiler::TNode<IntPtrT> tmp632;
    compiler::TNode<IntPtrT> tmp633;
    compiler::TNode<IntPtrT> tmp634;
    compiler::TNode<IntPtrT> tmp635;
    ca_.Bind(&block28, &tmp618, &tmp619, &tmp620, &tmp621, &tmp622, &tmp623, &tmp624, &tmp625, &tmp626, &tmp627, &tmp628, &tmp629, &tmp630, &tmp631, &tmp632, &tmp633, &tmp634, &tmp635);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 37);
    ca_.Goto(&block2, tmp618, tmp619, tmp620, tmp621, tmp622, tmp631);
  }

  if (block11.is_used()) {
    compiler::TNode<Context> tmp636;
    compiler::TNode<Object> tmp637;
    compiler::TNode<RawPtrT> tmp638;
    compiler::TNode<RawPtrT> tmp639;
    compiler::TNode<IntPtrT> tmp640;
    compiler::TNode<JSArray> tmp641;
    compiler::TNode<JSArray> tmp642;
    compiler::TNode<JSArray> tmp643;
    compiler::TNode<Map> tmp644;
    compiler::TNode<BoolT> tmp645;
    compiler::TNode<BoolT> tmp646;
    compiler::TNode<BoolT> tmp647;
    ca_.Bind(&block11, &tmp636, &tmp637, &tmp638, &tmp639, &tmp640, &tmp641, &tmp642, &tmp643, &tmp644, &tmp645, &tmp646, &tmp647);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 41);
    compiler::TNode<JSFunction> tmp648;
    USE(tmp648);
    tmp648 = ca_.UncheckedCast<JSFunction>(BaseBuiltinsFromDSLAssembler(state_).LoadTargetFromFrame());
    compiler::TNode<Oddball> tmp649;
    USE(tmp649);
    tmp649 = BaseBuiltinsFromDSLAssembler(state_).Undefined();
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 42);
    compiler::TNode<Int32T> tmp650;
    USE(tmp650);
    tmp650 = ca_.UncheckedCast<Int32T>(BaseBuiltinsFromDSLAssembler(state_).Convert7ATint328ATintptr(compiler::TNode<IntPtrT>{tmp640}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 40);
   CodeStubAssembler(state_).TailCallBuiltin(Builtins::kArrayShift, tmp636, tmp648, tmp649, tmp650);
  }

  if (block2.is_used()) {
    compiler::TNode<Context> tmp651;
    compiler::TNode<Object> tmp652;
    compiler::TNode<RawPtrT> tmp653;
    compiler::TNode<RawPtrT> tmp654;
    compiler::TNode<IntPtrT> tmp655;
    compiler::TNode<Object> tmp656;
    ca_.Bind(&block2, &tmp651, &tmp652, &tmp653, &tmp654, &tmp655, &tmp656);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 8);
    ca_.Goto(&block43, tmp651, tmp652, tmp653, tmp654, tmp655, tmp656);
  }

  if (block1.is_used()) {
    ca_.Bind(&block1);
    ca_.Goto(label_Slow);
  }

    compiler::TNode<Context> tmp657;
    compiler::TNode<Object> tmp658;
    compiler::TNode<RawPtrT> tmp659;
    compiler::TNode<RawPtrT> tmp660;
    compiler::TNode<IntPtrT> tmp661;
    compiler::TNode<Object> tmp662;
    ca_.Bind(&block43, &tmp657, &tmp658, &tmp659, &tmp660, &tmp661, &tmp662);
  return compiler::TNode<Object>{tmp662};
}

compiler::TNode<Object> ArrayShiftBuiltinsFromDSLAssembler::GenericArrayShift(compiler::TNode<Context> p_context, compiler::TNode<Object> p_receiver) {
  compiler::CodeAssemblerParameterizedLabel<Context, Object> block0(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number> block2(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number> block3(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number> block6(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number, Number, Number> block7(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number, Number, Number> block8(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number> block4(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number, Number, Number, Oddball> block9(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number, Number, Number, Oddball> block10(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number, Number, Number, Oddball> block11(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, JSReceiver, Number, Object, Number> block5(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, Object> block1(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, Object> block12(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
    ca_.Goto(&block0, p_context, p_receiver);

  if (block0.is_used()) {
    compiler::TNode<Context> tmp0;
    compiler::TNode<Object> tmp1;
    ca_.Bind(&block0, &tmp0, &tmp1);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 49);
    compiler::TNode<JSReceiver> tmp2;
    USE(tmp2);
    tmp2 = ca_.UncheckedCast<JSReceiver>(CodeStubAssembler(state_).ToObject_Inline(compiler::TNode<Context>{tmp0}, compiler::TNode<Object>{tmp1}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 52);
    compiler::TNode<Number> tmp3;
    USE(tmp3);
    tmp3 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).GetLengthProperty(compiler::TNode<Context>{tmp0}, compiler::TNode<Object>{tmp2}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 55);
    compiler::TNode<Number> tmp4;
    USE(tmp4);
    tmp4 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr20UT5ATSmi10HeapNumber17ATconstexpr_int31(0));
    compiler::TNode<BoolT> tmp5;
    USE(tmp5);
    tmp5 = ca_.UncheckedCast<BoolT>(BaseBuiltinsFromDSLAssembler(state_).IsNumberEqual(compiler::TNode<Number>{tmp3}, compiler::TNode<Number>{tmp4}));
    ca_.Branch(tmp5, &block2, &block3, tmp0, tmp1, tmp2, tmp3);
  }

  if (block2.is_used()) {
    compiler::TNode<Context> tmp6;
    compiler::TNode<Object> tmp7;
    compiler::TNode<JSReceiver> tmp8;
    compiler::TNode<Number> tmp9;
    ca_.Bind(&block2, &tmp6, &tmp7, &tmp8, &tmp9);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 57);
    compiler::TNode<String> tmp10;
    USE(tmp10);
    tmp10 = BaseBuiltinsFromDSLAssembler(state_).kLengthString();
    compiler::TNode<Smi> tmp11;
    USE(tmp11);
    tmp11 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).Convert5ATSmi17ATconstexpr_int31(0));
    CodeStubAssembler(state_).CallBuiltin(Builtins::kSetProperty, tmp6, tmp8, tmp10, tmp11);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 59);
    compiler::TNode<Oddball> tmp13;
    USE(tmp13);
    tmp13 = BaseBuiltinsFromDSLAssembler(state_).Undefined();
    ca_.Goto(&block1, tmp6, tmp7, tmp13);
  }

  if (block3.is_used()) {
    compiler::TNode<Context> tmp14;
    compiler::TNode<Object> tmp15;
    compiler::TNode<JSReceiver> tmp16;
    compiler::TNode<Number> tmp17;
    ca_.Bind(&block3, &tmp14, &tmp15, &tmp16, &tmp17);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 63);
    compiler::TNode<Smi> tmp18;
    USE(tmp18);
    tmp18 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).Convert5ATSmi17ATconstexpr_int31(0));
    compiler::TNode<Object> tmp19;
    USE(tmp19);
    tmp19 = ca_.UncheckedCast<Object>(CodeStubAssembler(state_).GetProperty(compiler::TNode<Context>{tmp14}, compiler::TNode<Object>{tmp16}, compiler::TNode<Object>{tmp18}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 65);
    compiler::TNode<Number> tmp20;
    USE(tmp20);
    tmp20 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr20UT5ATSmi10HeapNumber17ATconstexpr_int31(1));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 67);
    ca_.Goto(&block6, tmp14, tmp15, tmp16, tmp17, tmp19, tmp20);
  }

  if (block6.is_used()) {
    compiler::TNode<Context> tmp21;
    compiler::TNode<Object> tmp22;
    compiler::TNode<JSReceiver> tmp23;
    compiler::TNode<Number> tmp24;
    compiler::TNode<Object> tmp25;
    compiler::TNode<Number> tmp26;
    ca_.Bind(&block6, &tmp21, &tmp22, &tmp23, &tmp24, &tmp25, &tmp26);
    compiler::CodeAssemblerLabel label0(&ca_);
    compiler::CodeAssemblerLabel label1(&ca_);
    CodeStubAssembler(state_).BranchIfNumberLessThan(compiler::TNode<Number>{tmp26}, compiler::TNode<Number>{tmp24}, &label0, &label1);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block7, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp26, tmp24);
    }
    if (label1.is_used()) {
      ca_.Bind(&label1);
      ca_.Goto(&block8, tmp21, tmp22, tmp23, tmp24, tmp25, tmp26, tmp26, tmp24);
    }
  }

  if (block7.is_used()) {
    compiler::TNode<Context> tmp27;
    compiler::TNode<Object> tmp28;
    compiler::TNode<JSReceiver> tmp29;
    compiler::TNode<Number> tmp30;
    compiler::TNode<Object> tmp31;
    compiler::TNode<Number> tmp32;
    compiler::TNode<Number> tmp33;
    compiler::TNode<Number> tmp34;
    ca_.Bind(&block7, &tmp27, &tmp28, &tmp29, &tmp30, &tmp31, &tmp32, &tmp33, &tmp34);
    ca_.Goto(&block4, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32);
  }

  if (block8.is_used()) {
    compiler::TNode<Context> tmp35;
    compiler::TNode<Object> tmp36;
    compiler::TNode<JSReceiver> tmp37;
    compiler::TNode<Number> tmp38;
    compiler::TNode<Object> tmp39;
    compiler::TNode<Number> tmp40;
    compiler::TNode<Number> tmp41;
    compiler::TNode<Number> tmp42;
    ca_.Bind(&block8, &tmp35, &tmp36, &tmp37, &tmp38, &tmp39, &tmp40, &tmp41, &tmp42);
    ca_.Goto(&block5, tmp35, tmp36, tmp37, tmp38, tmp39, tmp40);
  }

  if (block4.is_used()) {
    compiler::TNode<Context> tmp43;
    compiler::TNode<Object> tmp44;
    compiler::TNode<JSReceiver> tmp45;
    compiler::TNode<Number> tmp46;
    compiler::TNode<Object> tmp47;
    compiler::TNode<Number> tmp48;
    ca_.Bind(&block4, &tmp43, &tmp44, &tmp45, &tmp46, &tmp47, &tmp48);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 69);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 72);
    compiler::TNode<Number> tmp49;
    USE(tmp49);
    tmp49 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr20UT5ATSmi10HeapNumber17ATconstexpr_int31(1));
    compiler::TNode<Number> tmp50;
    USE(tmp50);
    tmp50 = ca_.UncheckedCast<Number>(CodeStubAssembler(state_).NumberSub(compiler::TNode<Number>{tmp48}, compiler::TNode<Number>{tmp49}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 75);
    compiler::TNode<Oddball> tmp51;
    tmp51 = TORQUE_CAST(CodeStubAssembler(state_).CallBuiltin(Builtins::kHasProperty, tmp43, tmp45, tmp48));
    USE(tmp51);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 78);
    compiler::TNode<Oddball> tmp52;
    USE(tmp52);
    tmp52 = BaseBuiltinsFromDSLAssembler(state_).True();
    compiler::TNode<BoolT> tmp53;
    USE(tmp53);
    tmp53 = ca_.UncheckedCast<BoolT>(CodeStubAssembler(state_).WordEqual(compiler::TNode<HeapObject>{tmp51}, compiler::TNode<HeapObject>{tmp52}));
    ca_.Branch(tmp53, &block9, &block10, tmp43, tmp44, tmp45, tmp46, tmp47, tmp48, tmp48, tmp50, tmp51);
  }

  if (block9.is_used()) {
    compiler::TNode<Context> tmp54;
    compiler::TNode<Object> tmp55;
    compiler::TNode<JSReceiver> tmp56;
    compiler::TNode<Number> tmp57;
    compiler::TNode<Object> tmp58;
    compiler::TNode<Number> tmp59;
    compiler::TNode<Number> tmp60;
    compiler::TNode<Number> tmp61;
    compiler::TNode<Oddball> tmp62;
    ca_.Bind(&block9, &tmp54, &tmp55, &tmp56, &tmp57, &tmp58, &tmp59, &tmp60, &tmp61, &tmp62);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 80);
    compiler::TNode<Object> tmp63;
    USE(tmp63);
    tmp63 = ca_.UncheckedCast<Object>(CodeStubAssembler(state_).GetProperty(compiler::TNode<Context>{tmp54}, compiler::TNode<Object>{tmp56}, compiler::TNode<Object>{tmp60}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 83);
    CodeStubAssembler(state_).CallBuiltin(Builtins::kSetProperty, tmp54, tmp56, tmp61, tmp63);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 78);
    ca_.Goto(&block11, tmp54, tmp55, tmp56, tmp57, tmp58, tmp59, tmp60, tmp61, tmp62);
  }

  if (block10.is_used()) {
    compiler::TNode<Context> tmp65;
    compiler::TNode<Object> tmp66;
    compiler::TNode<JSReceiver> tmp67;
    compiler::TNode<Number> tmp68;
    compiler::TNode<Object> tmp69;
    compiler::TNode<Number> tmp70;
    compiler::TNode<Number> tmp71;
    compiler::TNode<Number> tmp72;
    compiler::TNode<Oddball> tmp73;
    ca_.Bind(&block10, &tmp65, &tmp66, &tmp67, &tmp68, &tmp69, &tmp70, &tmp71, &tmp72, &tmp73);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 86);
    compiler::TNode<Smi> tmp74;
    USE(tmp74);
    tmp74 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr14ATLanguageMode24ATconstexpr_LanguageMode(LanguageMode::kStrict));
    CodeStubAssembler(state_).CallBuiltin(Builtins::kDeleteProperty, tmp65, tmp67, tmp72, tmp74);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 78);
    ca_.Goto(&block11, tmp65, tmp66, tmp67, tmp68, tmp69, tmp70, tmp71, tmp72, tmp73);
  }

  if (block11.is_used()) {
    compiler::TNode<Context> tmp76;
    compiler::TNode<Object> tmp77;
    compiler::TNode<JSReceiver> tmp78;
    compiler::TNode<Number> tmp79;
    compiler::TNode<Object> tmp80;
    compiler::TNode<Number> tmp81;
    compiler::TNode<Number> tmp82;
    compiler::TNode<Number> tmp83;
    compiler::TNode<Oddball> tmp84;
    ca_.Bind(&block11, &tmp76, &tmp77, &tmp78, &tmp79, &tmp80, &tmp81, &tmp82, &tmp83, &tmp84);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 90);
    compiler::TNode<Number> tmp85;
    USE(tmp85);
    tmp85 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr20UT5ATSmi10HeapNumber17ATconstexpr_int31(1));
    compiler::TNode<Number> tmp86;
    USE(tmp86);
    tmp86 = ca_.UncheckedCast<Number>(CodeStubAssembler(state_).NumberAdd(compiler::TNode<Number>{tmp81}, compiler::TNode<Number>{tmp85}));
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 67);
    ca_.Goto(&block6, tmp76, tmp77, tmp78, tmp79, tmp80, tmp86);
  }

  if (block5.is_used()) {
    compiler::TNode<Context> tmp87;
    compiler::TNode<Object> tmp88;
    compiler::TNode<JSReceiver> tmp89;
    compiler::TNode<Number> tmp90;
    compiler::TNode<Object> tmp91;
    compiler::TNode<Number> tmp92;
    ca_.Bind(&block5, &tmp87, &tmp88, &tmp89, &tmp90, &tmp91, &tmp92);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 94);
    compiler::TNode<Number> tmp93;
    USE(tmp93);
    tmp93 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr20UT5ATSmi10HeapNumber17ATconstexpr_int31(1));
    compiler::TNode<Number> tmp94;
    USE(tmp94);
    tmp94 = ca_.UncheckedCast<Number>(CodeStubAssembler(state_).NumberSub(compiler::TNode<Number>{tmp90}, compiler::TNode<Number>{tmp93}));
    compiler::TNode<Smi> tmp95;
    USE(tmp95);
    tmp95 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr14ATLanguageMode24ATconstexpr_LanguageMode(LanguageMode::kStrict));
    CodeStubAssembler(state_).CallBuiltin(Builtins::kDeleteProperty, tmp87, tmp89, tmp94, tmp95);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 97);
    compiler::TNode<String> tmp97;
    USE(tmp97);
    tmp97 = BaseBuiltinsFromDSLAssembler(state_).kLengthString();
    compiler::TNode<Number> tmp98;
    USE(tmp98);
    tmp98 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr20UT5ATSmi10HeapNumber17ATconstexpr_int31(1));
    compiler::TNode<Number> tmp99;
    USE(tmp99);
    tmp99 = ca_.UncheckedCast<Number>(CodeStubAssembler(state_).NumberSub(compiler::TNode<Number>{tmp90}, compiler::TNode<Number>{tmp98}));
    CodeStubAssembler(state_).CallBuiltin(Builtins::kSetProperty, tmp87, tmp89, tmp97, tmp99);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 100);
    ca_.Goto(&block1, tmp87, tmp88, tmp91);
  }

  if (block1.is_used()) {
    compiler::TNode<Context> tmp101;
    compiler::TNode<Object> tmp102;
    compiler::TNode<Object> tmp103;
    ca_.Bind(&block1, &tmp101, &tmp102, &tmp103);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 46);
    ca_.Goto(&block12, tmp101, tmp102, tmp103);
  }

    compiler::TNode<Context> tmp104;
    compiler::TNode<Object> tmp105;
    compiler::TNode<Object> tmp106;
    ca_.Bind(&block12, &tmp104, &tmp105, &tmp106);
  return compiler::TNode<Object>{tmp106};
}

TF_BUILTIN(ArrayPrototypeShift, CodeStubAssembler) {
  compiler::CodeAssemblerState* state_ = state();  compiler::CodeAssembler ca_(state());
  TNode<Context> parameter0 = UncheckedCast<Context>(Parameter(Descriptor::kContext));
  USE(parameter0);
  Node* argc = Parameter(Descriptor::kJSActualArgumentsCount);
  TNode<IntPtrT> arguments_length(ChangeInt32ToIntPtr(argc));
  TNode<RawPtrT> arguments_frame = UncheckedCast<RawPtrT>(LoadFramePointer());
  BaseBuiltinsFromDSLAssembler::Arguments torque_arguments(GetFrameArguments(arguments_frame, arguments_length));
  CodeStubArguments arguments(this, torque_arguments);
  TNode<Object> parameter1 = arguments.GetReceiver();
USE(parameter1);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT> block0(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object, RawPtrT, RawPtrT, IntPtrT> block4(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object, RawPtrT, RawPtrT, IntPtrT, Object> block3(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT> block2(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
    ca_.Goto(&block0, parameter0, parameter1, torque_arguments.frame, torque_arguments.base, torque_arguments.length);

  if (block0.is_used()) {
    compiler::TNode<Context> tmp0;
    compiler::TNode<Object> tmp1;
    compiler::TNode<RawPtrT> tmp2;
    compiler::TNode<RawPtrT> tmp3;
    compiler::TNode<IntPtrT> tmp4;
    ca_.Bind(&block0, &tmp0, &tmp1, &tmp2, &tmp3, &tmp4);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 107);
    compiler::TNode<Object> tmp5;
    USE(tmp5);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp5 = ArrayShiftBuiltinsFromDSLAssembler(state_).TryFastArrayShift(compiler::TNode<Context>{tmp0}, compiler::TNode<Object>{tmp1}, BaseBuiltinsFromDSLAssembler::Arguments{compiler::TNode<RawPtrT>{tmp2}, compiler::TNode<RawPtrT>{tmp3}, compiler::TNode<IntPtrT>{tmp4}}, &label0);
    ca_.Goto(&block3, tmp0, tmp1, tmp2, tmp3, tmp4, tmp1, tmp2, tmp3, tmp4, tmp5);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block4, tmp0, tmp1, tmp2, tmp3, tmp4, tmp1, tmp2, tmp3, tmp4);
    }
  }

  if (block4.is_used()) {
    compiler::TNode<Context> tmp6;
    compiler::TNode<Object> tmp7;
    compiler::TNode<RawPtrT> tmp8;
    compiler::TNode<RawPtrT> tmp9;
    compiler::TNode<IntPtrT> tmp10;
    compiler::TNode<Object> tmp11;
    compiler::TNode<RawPtrT> tmp12;
    compiler::TNode<RawPtrT> tmp13;
    compiler::TNode<IntPtrT> tmp14;
    ca_.Bind(&block4, &tmp6, &tmp7, &tmp8, &tmp9, &tmp10, &tmp11, &tmp12, &tmp13, &tmp14);
    ca_.Goto(&block2, tmp6, tmp7, tmp8, tmp9, tmp10);
  }

  if (block3.is_used()) {
    compiler::TNode<Context> tmp15;
    compiler::TNode<Object> tmp16;
    compiler::TNode<RawPtrT> tmp17;
    compiler::TNode<RawPtrT> tmp18;
    compiler::TNode<IntPtrT> tmp19;
    compiler::TNode<Object> tmp20;
    compiler::TNode<RawPtrT> tmp21;
    compiler::TNode<RawPtrT> tmp22;
    compiler::TNode<IntPtrT> tmp23;
    compiler::TNode<Object> tmp24;
    ca_.Bind(&block3, &tmp15, &tmp16, &tmp17, &tmp18, &tmp19, &tmp20, &tmp21, &tmp22, &tmp23, &tmp24);
    arguments.PopAndReturn(tmp24);
  }

  if (block2.is_used()) {
    compiler::TNode<Context> tmp25;
    compiler::TNode<Object> tmp26;
    compiler::TNode<RawPtrT> tmp27;
    compiler::TNode<RawPtrT> tmp28;
    compiler::TNode<IntPtrT> tmp29;
    ca_.Bind(&block2, &tmp25, &tmp26, &tmp27, &tmp28, &tmp29);
    ca_.SetSourcePosition("../../src/builtins/array-shift.tq", 110);
    compiler::TNode<Object> tmp30;
    USE(tmp30);
    tmp30 = ca_.UncheckedCast<Object>(ArrayShiftBuiltinsFromDSLAssembler(state_).GenericArrayShift(compiler::TNode<Context>{tmp25}, compiler::TNode<Object>{tmp26}));
    arguments.PopAndReturn(tmp30);
  }
}

}  // namespace internal
}  // namespace v8

