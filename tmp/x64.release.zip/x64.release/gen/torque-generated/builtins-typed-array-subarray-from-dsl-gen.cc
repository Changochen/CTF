#include "src/builtins/builtins-utils-gen.h"
#include "src/builtins/builtins.h"
#include "src/code-factory.h"
#include "src/elements-kind.h"
#include "src/heap/factory-inl.h"
#include "src/objects.h"
#include "src/objects/arguments.h"
#include "src/objects/bigint.h"
#include "src/objects/free-space.h"
#include "src/objects/js-generator.h"
#include "src/objects/js-promise.h"
#include "src/objects/js-regexp-string-iterator.h"
#include "src/objects/module.h"
#include "src/objects/stack-frame-info.h"
#include "src/builtins/builtins-array-gen.h"
#include "src/builtins/builtins-collections-gen.h"
#include "src/builtins/builtins-data-view-gen.h"
#include "src/builtins/builtins-iterator-gen.h"
#include "src/builtins/builtins-proxy-gen.h"
#include "src/builtins/builtins-proxy-gen.h"
#include "src/builtins/builtins-regexp-gen.h"
#include "src/builtins/builtins-regexp-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-constructor-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "src/builtins/builtins-typed-array-gen.h"
#include "torque-generated/builtins-base-from-dsl-gen.h"
#include "torque-generated/builtins-growable-fixed-array-from-dsl-gen.h"
#include "torque-generated/builtins-arguments-from-dsl-gen.h"
#include "torque-generated/builtins-array-from-dsl-gen.h"
#include "torque-generated/builtins-array-copywithin-from-dsl-gen.h"
#include "torque-generated/builtins-array-filter-from-dsl-gen.h"
#include "torque-generated/builtins-array-find-from-dsl-gen.h"
#include "torque-generated/builtins-array-findindex-from-dsl-gen.h"
#include "torque-generated/builtins-array-foreach-from-dsl-gen.h"
#include "torque-generated/builtins-array-join-from-dsl-gen.h"
#include "torque-generated/builtins-array-lastindexof-from-dsl-gen.h"
#include "torque-generated/builtins-array-of-from-dsl-gen.h"
#include "torque-generated/builtins-array-map-from-dsl-gen.h"
#include "torque-generated/builtins-array-reverse-from-dsl-gen.h"
#include "torque-generated/builtins-array-shift-from-dsl-gen.h"
#include "torque-generated/builtins-array-slice-from-dsl-gen.h"
#include "torque-generated/builtins-array-splice-from-dsl-gen.h"
#include "torque-generated/builtins-array-unshift-from-dsl-gen.h"
#include "torque-generated/builtins-collections-from-dsl-gen.h"
#include "torque-generated/builtins-data-view-from-dsl-gen.h"
#include "torque-generated/builtins-extras-utils-from-dsl-gen.h"
#include "torque-generated/builtins-iterator-from-dsl-gen.h"
#include "torque-generated/builtins-object-from-dsl-gen.h"
#include "torque-generated/builtins-proxy-from-dsl-gen.h"
#include "torque-generated/builtins-regexp-from-dsl-gen.h"
#include "torque-generated/builtins-regexp-replace-from-dsl-gen.h"
#include "torque-generated/builtins-string-from-dsl-gen.h"
#include "torque-generated/builtins-string-html-from-dsl-gen.h"
#include "torque-generated/builtins-string-repeat-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-createtypedarray-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-every-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-filter-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-find-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-findindex-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-foreach-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-reduce-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-reduceright-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-slice-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-some-from-dsl-gen.h"
#include "torque-generated/builtins-typed-array-subarray-from-dsl-gen.h"
#include "torque-generated/builtins-test-from-dsl-gen.h"

namespace v8 {
namespace internal {

TF_BUILTIN(TypedArrayPrototypeSubArray, CodeStubAssembler) {
  compiler::CodeAssemblerState* state_ = state();  compiler::CodeAssembler ca_(state());
  TNode<Context> parameter0 = UncheckedCast<Context>(Parameter(Descriptor::kContext));
  USE(parameter0);
  Node* argc = Parameter(Descriptor::kJSActualArgumentsCount);
  TNode<IntPtrT> arguments_length(ChangeInt32ToIntPtr(argc));
  TNode<RawPtrT> arguments_frame = UncheckedCast<RawPtrT>(LoadFramePointer());
  BaseBuiltinsFromDSLAssembler::Arguments torque_arguments(GetFrameArguments(arguments_frame, arguments_length));
  CodeStubArguments arguments(this, torque_arguments);
  TNode<Object> parameter1 = arguments.GetReceiver();
USE(parameter1);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT> block0(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object> block4(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, Object, JSTypedArray> block3(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT> block2(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray> block1(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object> block5(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object> block6(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT> block8(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT> block7(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object> block9(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object> block10(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object, IntPtrT> block12(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object, IntPtrT> block11(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object, IntPtrT, Smi, UintPtrT, Map, Int32T, UintPtrT, UintPtrT, UintPtrT, Map, Int32T, Smi, Smi, UintPtrT, UintPtrT> block16(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object, IntPtrT, Smi, UintPtrT, Map, Int32T, UintPtrT, UintPtrT, UintPtrT, Map, Int32T, Smi, Smi, UintPtrT, UintPtrT> block17(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object, IntPtrT, Smi, UintPtrT, Map, Int32T, UintPtrT, UintPtrT, UintPtrT, Map, Int32T, Smi, Smi, UintPtrT> block15(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object, IntPtrT, Smi, UintPtrT, Map, Int32T, UintPtrT, UintPtrT> block14(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
  compiler::CodeAssemblerParameterizedLabel<Context, Object, RawPtrT, RawPtrT, IntPtrT, JSTypedArray, JSArrayBuffer, IntPtrT, Object, IntPtrT, Object, IntPtrT, Smi, UintPtrT, Map, Int32T, UintPtrT, UintPtrT, UintPtrT> block13(&ca_, compiler::CodeAssemblerLabel::kNonDeferred);
    ca_.Goto(&block0, parameter0, parameter1, torque_arguments.frame, torque_arguments.base, torque_arguments.length);

  if (block0.is_used()) {
    compiler::TNode<Context> tmp0;
    compiler::TNode<Object> tmp1;
    compiler::TNode<RawPtrT> tmp2;
    compiler::TNode<RawPtrT> tmp3;
    compiler::TNode<IntPtrT> tmp4;
    ca_.Bind(&block0, &tmp0, &tmp1, &tmp2, &tmp3, &tmp4);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 14);
    compiler::TNode<JSTypedArray> tmp5;
    USE(tmp5);
    compiler::CodeAssemblerLabel label0(&ca_);
    tmp5 = BaseBuiltinsFromDSLAssembler(state_).Cast12JSTypedArray(compiler::TNode<Context>{tmp0}, compiler::TNode<Object>{tmp1}, &label0);
    ca_.Goto(&block3, tmp0, tmp1, tmp2, tmp3, tmp4, tmp1, tmp5);
    if (label0.is_used()) {
      ca_.Bind(&label0);
      ca_.Goto(&block4, tmp0, tmp1, tmp2, tmp3, tmp4, tmp1);
    }
  }

  if (block4.is_used()) {
    compiler::TNode<Context> tmp6;
    compiler::TNode<Object> tmp7;
    compiler::TNode<RawPtrT> tmp8;
    compiler::TNode<RawPtrT> tmp9;
    compiler::TNode<IntPtrT> tmp10;
    compiler::TNode<Object> tmp11;
    ca_.Bind(&block4, &tmp6, &tmp7, &tmp8, &tmp9, &tmp10, &tmp11);
    ca_.Goto(&block2, tmp6, tmp7, tmp8, tmp9, tmp10);
  }

  if (block3.is_used()) {
    compiler::TNode<Context> tmp12;
    compiler::TNode<Object> tmp13;
    compiler::TNode<RawPtrT> tmp14;
    compiler::TNode<RawPtrT> tmp15;
    compiler::TNode<IntPtrT> tmp16;
    compiler::TNode<Object> tmp17;
    compiler::TNode<JSTypedArray> tmp18;
    ca_.Bind(&block3, &tmp12, &tmp13, &tmp14, &tmp15, &tmp16, &tmp17, &tmp18);
    ca_.Goto(&block1, tmp12, tmp13, tmp14, tmp15, tmp16, tmp18);
  }

  if (block2.is_used()) {
    compiler::TNode<Context> tmp19;
    compiler::TNode<Object> tmp20;
    compiler::TNode<RawPtrT> tmp21;
    compiler::TNode<RawPtrT> tmp22;
    compiler::TNode<IntPtrT> tmp23;
    ca_.Bind(&block2, &tmp19, &tmp20, &tmp21, &tmp22, &tmp23);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 15);
    CodeStubAssembler(state_).ThrowTypeError(compiler::TNode<Context>{tmp19}, MessageTemplate::kIncompatibleMethodReceiver, "%TypedArray%.prototype.subarray");
  }

  if (block1.is_used()) {
    compiler::TNode<Context> tmp24;
    compiler::TNode<Object> tmp25;
    compiler::TNode<RawPtrT> tmp26;
    compiler::TNode<RawPtrT> tmp27;
    compiler::TNode<IntPtrT> tmp28;
    compiler::TNode<JSTypedArray> tmp29;
    ca_.Bind(&block1, &tmp24, &tmp25, &tmp26, &tmp27, &tmp28, &tmp29);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 18);
    compiler::TNode<JSArrayBuffer> tmp30;
    USE(tmp30);
    tmp30 = ca_.UncheckedCast<JSArrayBuffer>(TypedArrayBuiltinsAssembler(state_).GetBuffer(compiler::TNode<Context>{tmp24}, compiler::TNode<JSTypedArray>{tmp29}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 21);
    compiler::TNode<Smi> tmp31;
    USE(tmp31);
    tmp31 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).LoadJSTypedArrayLength(compiler::TNode<JSTypedArray>{tmp29}));
    compiler::TNode<IntPtrT> tmp32;
    USE(tmp32);
    tmp32 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).Convert8ATintptr5ATSmi(compiler::TNode<Smi>{tmp31}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 27);
    compiler::TNode<IntPtrT> tmp33;
    USE(tmp33);
    tmp33 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr8ATintptr17ATconstexpr_int31(0));
    compiler::TNode<Object> tmp34;
    USE(tmp34);
    tmp34 = ca_.UncheckedCast<Object>(CodeStubAssembler(state_).GetArgumentValue(BaseBuiltinsFromDSLAssembler::Arguments{compiler::TNode<RawPtrT>{tmp26}, compiler::TNode<RawPtrT>{tmp27}, compiler::TNode<IntPtrT>{tmp28}}, compiler::TNode<IntPtrT>{tmp33}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 29);
    compiler::TNode<Oddball> tmp35;
    USE(tmp35);
    tmp35 = BaseBuiltinsFromDSLAssembler(state_).Undefined();
    compiler::TNode<BoolT> tmp36;
    USE(tmp36);
    tmp36 = ca_.UncheckedCast<BoolT>(CodeStubAssembler(state_).WordNotEqual(compiler::TNode<Object>{tmp34}, compiler::TNode<HeapObject>{tmp35}));
    ca_.Branch(tmp36, &block5, &block6, tmp24, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp32, tmp34);
  }

  if (block5.is_used()) {
    compiler::TNode<Context> tmp37;
    compiler::TNode<Object> tmp38;
    compiler::TNode<RawPtrT> tmp39;
    compiler::TNode<RawPtrT> tmp40;
    compiler::TNode<IntPtrT> tmp41;
    compiler::TNode<JSTypedArray> tmp42;
    compiler::TNode<JSArrayBuffer> tmp43;
    compiler::TNode<IntPtrT> tmp44;
    compiler::TNode<Object> tmp45;
    ca_.Bind(&block5, &tmp37, &tmp38, &tmp39, &tmp40, &tmp41, &tmp42, &tmp43, &tmp44, &tmp45);
    compiler::TNode<IntPtrT> tmp46;
    USE(tmp46);
    tmp46 = ca_.UncheckedCast<IntPtrT>(CodeStubAssembler(state_).ConvertToRelativeIndex(compiler::TNode<Context>{tmp37}, compiler::TNode<Object>{tmp45}, compiler::TNode<IntPtrT>{tmp44}));
    ca_.Goto(&block8, tmp37, tmp38, tmp39, tmp40, tmp41, tmp42, tmp43, tmp44, tmp45, tmp46);
  }

  if (block6.is_used()) {
    compiler::TNode<Context> tmp47;
    compiler::TNode<Object> tmp48;
    compiler::TNode<RawPtrT> tmp49;
    compiler::TNode<RawPtrT> tmp50;
    compiler::TNode<IntPtrT> tmp51;
    compiler::TNode<JSTypedArray> tmp52;
    compiler::TNode<JSArrayBuffer> tmp53;
    compiler::TNode<IntPtrT> tmp54;
    compiler::TNode<Object> tmp55;
    ca_.Bind(&block6, &tmp47, &tmp48, &tmp49, &tmp50, &tmp51, &tmp52, &tmp53, &tmp54, &tmp55);
    compiler::TNode<IntPtrT> tmp56;
    USE(tmp56);
    tmp56 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr8ATintptr17ATconstexpr_int31(0));
    ca_.Goto(&block7, tmp47, tmp48, tmp49, tmp50, tmp51, tmp52, tmp53, tmp54, tmp55, tmp56);
  }

  if (block8.is_used()) {
    compiler::TNode<Context> tmp57;
    compiler::TNode<Object> tmp58;
    compiler::TNode<RawPtrT> tmp59;
    compiler::TNode<RawPtrT> tmp60;
    compiler::TNode<IntPtrT> tmp61;
    compiler::TNode<JSTypedArray> tmp62;
    compiler::TNode<JSArrayBuffer> tmp63;
    compiler::TNode<IntPtrT> tmp64;
    compiler::TNode<Object> tmp65;
    compiler::TNode<IntPtrT> tmp66;
    ca_.Bind(&block8, &tmp57, &tmp58, &tmp59, &tmp60, &tmp61, &tmp62, &tmp63, &tmp64, &tmp65, &tmp66);
    ca_.Goto(&block7, tmp57, tmp58, tmp59, tmp60, tmp61, tmp62, tmp63, tmp64, tmp65, tmp66);
  }

  if (block7.is_used()) {
    compiler::TNode<Context> tmp67;
    compiler::TNode<Object> tmp68;
    compiler::TNode<RawPtrT> tmp69;
    compiler::TNode<RawPtrT> tmp70;
    compiler::TNode<IntPtrT> tmp71;
    compiler::TNode<JSTypedArray> tmp72;
    compiler::TNode<JSArrayBuffer> tmp73;
    compiler::TNode<IntPtrT> tmp74;
    compiler::TNode<Object> tmp75;
    compiler::TNode<IntPtrT> tmp76;
    ca_.Bind(&block7, &tmp67, &tmp68, &tmp69, &tmp70, &tmp71, &tmp72, &tmp73, &tmp74, &tmp75, &tmp76);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 28);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 35);
    compiler::TNode<IntPtrT> tmp77;
    USE(tmp77);
    tmp77 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr8ATintptr17ATconstexpr_int31(1));
    compiler::TNode<Object> tmp78;
    USE(tmp78);
    tmp78 = ca_.UncheckedCast<Object>(CodeStubAssembler(state_).GetArgumentValue(BaseBuiltinsFromDSLAssembler::Arguments{compiler::TNode<RawPtrT>{tmp69}, compiler::TNode<RawPtrT>{tmp70}, compiler::TNode<IntPtrT>{tmp71}}, compiler::TNode<IntPtrT>{tmp77}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 37);
    compiler::TNode<Oddball> tmp79;
    USE(tmp79);
    tmp79 = BaseBuiltinsFromDSLAssembler(state_).Undefined();
    compiler::TNode<BoolT> tmp80;
    USE(tmp80);
    tmp80 = ca_.UncheckedCast<BoolT>(CodeStubAssembler(state_).WordNotEqual(compiler::TNode<Object>{tmp78}, compiler::TNode<HeapObject>{tmp79}));
    ca_.Branch(tmp80, &block9, &block10, tmp67, tmp68, tmp69, tmp70, tmp71, tmp72, tmp73, tmp74, tmp75, tmp76, tmp78);
  }

  if (block9.is_used()) {
    compiler::TNode<Context> tmp81;
    compiler::TNode<Object> tmp82;
    compiler::TNode<RawPtrT> tmp83;
    compiler::TNode<RawPtrT> tmp84;
    compiler::TNode<IntPtrT> tmp85;
    compiler::TNode<JSTypedArray> tmp86;
    compiler::TNode<JSArrayBuffer> tmp87;
    compiler::TNode<IntPtrT> tmp88;
    compiler::TNode<Object> tmp89;
    compiler::TNode<IntPtrT> tmp90;
    compiler::TNode<Object> tmp91;
    ca_.Bind(&block9, &tmp81, &tmp82, &tmp83, &tmp84, &tmp85, &tmp86, &tmp87, &tmp88, &tmp89, &tmp90, &tmp91);
    compiler::TNode<IntPtrT> tmp92;
    USE(tmp92);
    tmp92 = ca_.UncheckedCast<IntPtrT>(CodeStubAssembler(state_).ConvertToRelativeIndex(compiler::TNode<Context>{tmp81}, compiler::TNode<Object>{tmp91}, compiler::TNode<IntPtrT>{tmp88}));
    ca_.Goto(&block12, tmp81, tmp82, tmp83, tmp84, tmp85, tmp86, tmp87, tmp88, tmp89, tmp90, tmp91, tmp92);
  }

  if (block10.is_used()) {
    compiler::TNode<Context> tmp93;
    compiler::TNode<Object> tmp94;
    compiler::TNode<RawPtrT> tmp95;
    compiler::TNode<RawPtrT> tmp96;
    compiler::TNode<IntPtrT> tmp97;
    compiler::TNode<JSTypedArray> tmp98;
    compiler::TNode<JSArrayBuffer> tmp99;
    compiler::TNode<IntPtrT> tmp100;
    compiler::TNode<Object> tmp101;
    compiler::TNode<IntPtrT> tmp102;
    compiler::TNode<Object> tmp103;
    ca_.Bind(&block10, &tmp93, &tmp94, &tmp95, &tmp96, &tmp97, &tmp98, &tmp99, &tmp100, &tmp101, &tmp102, &tmp103);
    ca_.Goto(&block11, tmp93, tmp94, tmp95, tmp96, tmp97, tmp98, tmp99, tmp100, tmp101, tmp102, tmp103, tmp100);
  }

  if (block12.is_used()) {
    compiler::TNode<Context> tmp104;
    compiler::TNode<Object> tmp105;
    compiler::TNode<RawPtrT> tmp106;
    compiler::TNode<RawPtrT> tmp107;
    compiler::TNode<IntPtrT> tmp108;
    compiler::TNode<JSTypedArray> tmp109;
    compiler::TNode<JSArrayBuffer> tmp110;
    compiler::TNode<IntPtrT> tmp111;
    compiler::TNode<Object> tmp112;
    compiler::TNode<IntPtrT> tmp113;
    compiler::TNode<Object> tmp114;
    compiler::TNode<IntPtrT> tmp115;
    ca_.Bind(&block12, &tmp104, &tmp105, &tmp106, &tmp107, &tmp108, &tmp109, &tmp110, &tmp111, &tmp112, &tmp113, &tmp114, &tmp115);
    ca_.Goto(&block11, tmp104, tmp105, tmp106, tmp107, tmp108, tmp109, tmp110, tmp111, tmp112, tmp113, tmp114, tmp115);
  }

  if (block11.is_used()) {
    compiler::TNode<Context> tmp116;
    compiler::TNode<Object> tmp117;
    compiler::TNode<RawPtrT> tmp118;
    compiler::TNode<RawPtrT> tmp119;
    compiler::TNode<IntPtrT> tmp120;
    compiler::TNode<JSTypedArray> tmp121;
    compiler::TNode<JSArrayBuffer> tmp122;
    compiler::TNode<IntPtrT> tmp123;
    compiler::TNode<Object> tmp124;
    compiler::TNode<IntPtrT> tmp125;
    compiler::TNode<Object> tmp126;
    compiler::TNode<IntPtrT> tmp127;
    ca_.Bind(&block11, &tmp116, &tmp117, &tmp118, &tmp119, &tmp120, &tmp121, &tmp122, &tmp123, &tmp124, &tmp125, &tmp126, &tmp127);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 36);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 40);
    compiler::TNode<IntPtrT> tmp128;
    USE(tmp128);
    tmp128 = ca_.UncheckedCast<IntPtrT>(CodeStubAssembler(state_).IntPtrSub(compiler::TNode<IntPtrT>{tmp127}, compiler::TNode<IntPtrT>{tmp125}));
    compiler::TNode<IntPtrT> tmp129;
    USE(tmp129);
    tmp129 = ca_.UncheckedCast<IntPtrT>(BaseBuiltinsFromDSLAssembler(state_).FromConstexpr8ATintptr17ATconstexpr_int31(0));
    compiler::TNode<IntPtrT> tmp130;
    USE(tmp130);
    tmp130 = ca_.UncheckedCast<IntPtrT>(CodeStubAssembler(state_).IntPtrMax(compiler::TNode<IntPtrT>{tmp128}, compiler::TNode<IntPtrT>{tmp129}));
    compiler::TNode<Smi> tmp131;
    USE(tmp131);
    tmp131 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).Convert13ATPositiveSmi8ATintptr(compiler::TNode<IntPtrT>{tmp130}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 45);
    compiler::TNode<UintPtrT> tmp132;
    USE(tmp132);
    compiler::TNode<Map> tmp133;
    USE(tmp133);
    compiler::TNode<Int32T> tmp134;
    USE(tmp134);
    std::tie(tmp132, tmp133, tmp134) = TypedArrayBuiltinsAssembler(state_).GetTypedArrayElementsInfo(compiler::TNode<JSTypedArray>{tmp121}).Flatten();
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 48);
    compiler::TNode<UintPtrT> tmp135;
    USE(tmp135);
    tmp135 = ca_.UncheckedCast<UintPtrT>(BaseBuiltinsFromDSLAssembler(state_).LoadJSArrayBufferViewByteOffset(compiler::TNode<JSArrayBufferView>{tmp121}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 51);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 52);
    compiler::TNode<Smi> tmp136;
    USE(tmp136);
    tmp136 = ca_.UncheckedCast<Smi>(BaseBuiltinsFromDSLAssembler(state_).Convert13ATPositiveSmi8ATintptr(compiler::TNode<IntPtrT>{tmp125}));
    ca_.SetSourcePosition("../../src/builtins/typed-array.tq", 11);
    compiler::TNode<UintPtrT> tmp137;
    USE(tmp137);
    tmp137 = ca_.UncheckedCast<UintPtrT>(BaseBuiltinsFromDSLAssembler(state_).Convert9ATuintptr13ATPositiveSmi(compiler::TNode<Smi>{tmp136}));
    ca_.SetSourcePosition("../../src/builtins/typed-array.tq", 12);
    compiler::TNode<UintPtrT> tmp138;
    USE(tmp138);
    tmp138 = ca_.UncheckedCast<UintPtrT>(CodeStubAssembler(state_).WordShl(compiler::TNode<UintPtrT>{tmp137}, compiler::TNode<UintPtrT>{tmp132}));
    ca_.SetSourcePosition("../../src/builtins/typed-array.tq", 15);
    compiler::TNode<UintPtrT> tmp139;
    USE(tmp139);
    tmp139 = ca_.UncheckedCast<UintPtrT>(CodeStubAssembler(state_).WordShr(compiler::TNode<UintPtrT>{tmp138}, compiler::TNode<UintPtrT>{tmp132}));
    compiler::TNode<BoolT> tmp140;
    USE(tmp140);
    tmp140 = ca_.UncheckedCast<BoolT>(CodeStubAssembler(state_).WordNotEqual(compiler::TNode<UintPtrT>{tmp139}, compiler::TNode<UintPtrT>{tmp137}));
    ca_.Branch(tmp140, &block16, &block17, tmp116, tmp117, tmp118, tmp119, tmp120, tmp121, tmp122, tmp123, tmp124, tmp125, tmp126, tmp127, tmp131, tmp132, tmp133, tmp134, tmp135, tmp135, tmp132, tmp133, tmp134, tmp136, tmp136, tmp137, tmp138);
  }

  if (block16.is_used()) {
    compiler::TNode<Context> tmp141;
    compiler::TNode<Object> tmp142;
    compiler::TNode<RawPtrT> tmp143;
    compiler::TNode<RawPtrT> tmp144;
    compiler::TNode<IntPtrT> tmp145;
    compiler::TNode<JSTypedArray> tmp146;
    compiler::TNode<JSArrayBuffer> tmp147;
    compiler::TNode<IntPtrT> tmp148;
    compiler::TNode<Object> tmp149;
    compiler::TNode<IntPtrT> tmp150;
    compiler::TNode<Object> tmp151;
    compiler::TNode<IntPtrT> tmp152;
    compiler::TNode<Smi> tmp153;
    compiler::TNode<UintPtrT> tmp154;
    compiler::TNode<Map> tmp155;
    compiler::TNode<Int32T> tmp156;
    compiler::TNode<UintPtrT> tmp157;
    compiler::TNode<UintPtrT> tmp158;
    compiler::TNode<UintPtrT> tmp159;
    compiler::TNode<Map> tmp160;
    compiler::TNode<Int32T> tmp161;
    compiler::TNode<Smi> tmp162;
    compiler::TNode<Smi> tmp163;
    compiler::TNode<UintPtrT> tmp164;
    compiler::TNode<UintPtrT> tmp165;
    ca_.Bind(&block16, &tmp141, &tmp142, &tmp143, &tmp144, &tmp145, &tmp146, &tmp147, &tmp148, &tmp149, &tmp150, &tmp151, &tmp152, &tmp153, &tmp154, &tmp155, &tmp156, &tmp157, &tmp158, &tmp159, &tmp160, &tmp161, &tmp162, &tmp163, &tmp164, &tmp165);
    ca_.Goto(&block14, tmp141, tmp142, tmp143, tmp144, tmp145, tmp146, tmp147, tmp148, tmp149, tmp150, tmp151, tmp152, tmp153, tmp154, tmp155, tmp156, tmp157, tmp158);
  }

  if (block17.is_used()) {
    compiler::TNode<Context> tmp166;
    compiler::TNode<Object> tmp167;
    compiler::TNode<RawPtrT> tmp168;
    compiler::TNode<RawPtrT> tmp169;
    compiler::TNode<IntPtrT> tmp170;
    compiler::TNode<JSTypedArray> tmp171;
    compiler::TNode<JSArrayBuffer> tmp172;
    compiler::TNode<IntPtrT> tmp173;
    compiler::TNode<Object> tmp174;
    compiler::TNode<IntPtrT> tmp175;
    compiler::TNode<Object> tmp176;
    compiler::TNode<IntPtrT> tmp177;
    compiler::TNode<Smi> tmp178;
    compiler::TNode<UintPtrT> tmp179;
    compiler::TNode<Map> tmp180;
    compiler::TNode<Int32T> tmp181;
    compiler::TNode<UintPtrT> tmp182;
    compiler::TNode<UintPtrT> tmp183;
    compiler::TNode<UintPtrT> tmp184;
    compiler::TNode<Map> tmp185;
    compiler::TNode<Int32T> tmp186;
    compiler::TNode<Smi> tmp187;
    compiler::TNode<Smi> tmp188;
    compiler::TNode<UintPtrT> tmp189;
    compiler::TNode<UintPtrT> tmp190;
    ca_.Bind(&block17, &tmp166, &tmp167, &tmp168, &tmp169, &tmp170, &tmp171, &tmp172, &tmp173, &tmp174, &tmp175, &tmp176, &tmp177, &tmp178, &tmp179, &tmp180, &tmp181, &tmp182, &tmp183, &tmp184, &tmp185, &tmp186, &tmp187, &tmp188, &tmp189, &tmp190);
    ca_.SetSourcePosition("../../src/builtins/typed-array.tq", 16);
    ca_.Goto(&block15, tmp166, tmp167, tmp168, tmp169, tmp170, tmp171, tmp172, tmp173, tmp174, tmp175, tmp176, tmp177, tmp178, tmp179, tmp180, tmp181, tmp182, tmp183, tmp184, tmp185, tmp186, tmp187, tmp188, tmp190);
  }

  if (block15.is_used()) {
    compiler::TNode<Context> tmp191;
    compiler::TNode<Object> tmp192;
    compiler::TNode<RawPtrT> tmp193;
    compiler::TNode<RawPtrT> tmp194;
    compiler::TNode<IntPtrT> tmp195;
    compiler::TNode<JSTypedArray> tmp196;
    compiler::TNode<JSArrayBuffer> tmp197;
    compiler::TNode<IntPtrT> tmp198;
    compiler::TNode<Object> tmp199;
    compiler::TNode<IntPtrT> tmp200;
    compiler::TNode<Object> tmp201;
    compiler::TNode<IntPtrT> tmp202;
    compiler::TNode<Smi> tmp203;
    compiler::TNode<UintPtrT> tmp204;
    compiler::TNode<Map> tmp205;
    compiler::TNode<Int32T> tmp206;
    compiler::TNode<UintPtrT> tmp207;
    compiler::TNode<UintPtrT> tmp208;
    compiler::TNode<UintPtrT> tmp209;
    compiler::TNode<Map> tmp210;
    compiler::TNode<Int32T> tmp211;
    compiler::TNode<Smi> tmp212;
    compiler::TNode<Smi> tmp213;
    compiler::TNode<UintPtrT> tmp214;
    ca_.Bind(&block15, &tmp191, &tmp192, &tmp193, &tmp194, &tmp195, &tmp196, &tmp197, &tmp198, &tmp199, &tmp200, &tmp201, &tmp202, &tmp203, &tmp204, &tmp205, &tmp206, &tmp207, &tmp208, &tmp209, &tmp210, &tmp211, &tmp212, &tmp213, &tmp214);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 52);
    ca_.Goto(&block13, tmp191, tmp192, tmp193, tmp194, tmp195, tmp196, tmp197, tmp198, tmp199, tmp200, tmp201, tmp202, tmp203, tmp204, tmp205, tmp206, tmp207, tmp208, tmp214);
  }

  if (block14.is_used()) {
    compiler::TNode<Context> tmp215;
    compiler::TNode<Object> tmp216;
    compiler::TNode<RawPtrT> tmp217;
    compiler::TNode<RawPtrT> tmp218;
    compiler::TNode<IntPtrT> tmp219;
    compiler::TNode<JSTypedArray> tmp220;
    compiler::TNode<JSArrayBuffer> tmp221;
    compiler::TNode<IntPtrT> tmp222;
    compiler::TNode<Object> tmp223;
    compiler::TNode<IntPtrT> tmp224;
    compiler::TNode<Object> tmp225;
    compiler::TNode<IntPtrT> tmp226;
    compiler::TNode<Smi> tmp227;
    compiler::TNode<UintPtrT> tmp228;
    compiler::TNode<Map> tmp229;
    compiler::TNode<Int32T> tmp230;
    compiler::TNode<UintPtrT> tmp231;
    compiler::TNode<UintPtrT> tmp232;
    ca_.Bind(&block14, &tmp215, &tmp216, &tmp217, &tmp218, &tmp219, &tmp220, &tmp221, &tmp222, &tmp223, &tmp224, &tmp225, &tmp226, &tmp227, &tmp228, &tmp229, &tmp230, &tmp231, &tmp232);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 53);
    CodeStubAssembler(state_).ThrowRangeError(compiler::TNode<Context>{tmp215}, MessageTemplate::kInvalidArrayBufferLength);
  }

  if (block13.is_used()) {
    compiler::TNode<Context> tmp233;
    compiler::TNode<Object> tmp234;
    compiler::TNode<RawPtrT> tmp235;
    compiler::TNode<RawPtrT> tmp236;
    compiler::TNode<IntPtrT> tmp237;
    compiler::TNode<JSTypedArray> tmp238;
    compiler::TNode<JSArrayBuffer> tmp239;
    compiler::TNode<IntPtrT> tmp240;
    compiler::TNode<Object> tmp241;
    compiler::TNode<IntPtrT> tmp242;
    compiler::TNode<Object> tmp243;
    compiler::TNode<IntPtrT> tmp244;
    compiler::TNode<Smi> tmp245;
    compiler::TNode<UintPtrT> tmp246;
    compiler::TNode<Map> tmp247;
    compiler::TNode<Int32T> tmp248;
    compiler::TNode<UintPtrT> tmp249;
    compiler::TNode<UintPtrT> tmp250;
    compiler::TNode<UintPtrT> tmp251;
    ca_.Bind(&block13, &tmp233, &tmp234, &tmp235, &tmp236, &tmp237, &tmp238, &tmp239, &tmp240, &tmp241, &tmp242, &tmp243, &tmp244, &tmp245, &tmp246, &tmp247, &tmp248, &tmp249, &tmp250, &tmp251);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 51);
    compiler::TNode<UintPtrT> tmp252;
    USE(tmp252);
    tmp252 = ca_.UncheckedCast<UintPtrT>(CodeStubAssembler(state_).UintPtrAdd(compiler::TNode<UintPtrT>{tmp250}, compiler::TNode<UintPtrT>{tmp251}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 56);
    compiler::TNode<Number> tmp253;
    USE(tmp253);
    tmp253 = ca_.UncheckedCast<Number>(BaseBuiltinsFromDSLAssembler(state_).Convert20UT5ATSmi10HeapNumber9ATuintptr(compiler::TNode<UintPtrT>{tmp252}));
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 61);
    ca_.SetSourcePosition("../../src/builtins/typed-array-subarray.tq", 60);
    compiler::TNode<JSTypedArray> tmp254;
    USE(tmp254);
    tmp254 = ca_.UncheckedCast<JSTypedArray>(TypedArrayCreatetypedarrayBuiltinsFromDSLAssembler(state_).TypedArraySpeciesCreate(compiler::TNode<Context>{tmp233}, "%TypedArray%.prototype.subarray", 3, compiler::TNode<JSTypedArray>{tmp238}, compiler::TNode<Object>{tmp239}, compiler::TNode<Object>{tmp253}, compiler::TNode<Object>{tmp245}));
    arguments.PopAndReturn(tmp254);
  }
}

}  // namespace internal
}  // namespace v8

